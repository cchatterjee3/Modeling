var searchData=
[
  ['undefined',['UNDEFINED',['../namespace_traffic_model_event_library.html#a7fd24d8a38718854d96c21ff8c66ad40a5a11660cbd9d8bdda66323321e4b7f99',1,'TrafficModelEventLibrary::UNDEFINED()'],['../namespace_traffic_model_objects_library.html#a536f1e1adbd3bc9bf06bcf717d223ddfa93bed2040bad16008ba7fc1aa91041f6',1,'TrafficModelObjectsLibrary::UNDEFINED()']]]
];
