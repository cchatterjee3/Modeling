var searchData=
[
  ['destinationclass',['DestinationClass',['../class_traffic_model_objects_library_1_1_destination_class.html#a7c9fcd09b8266bba5166ac04b2cb3ba8',1,'TrafficModelObjectsLibrary::DestinationClass::DestinationClass(void)'],['../class_traffic_model_objects_library_1_1_destination_class.html#af302f0582c86424ed048fa110c96d175',1,'TrafficModelObjectsLibrary::DestinationClass::DestinationClass(int Index, TrafficModelObject *TrafficModel, double AverageCrossingTime)']]],
  ['destinationscount',['DestinationsCount',['../class_traffic_model_objects_library_1_1_traffic_model_class.html#a0ae3856485572629f5ff0e1226126eae',1,'TrafficModelObjectsLibrary::TrafficModelClass']]]
];
