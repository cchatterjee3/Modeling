var searchData=
[
  ['nbucket',['nbucket',['../class_simulator_objects_library_1_1_c_queue.html#a00deee0fca645415ccc88737fc2904c2',1,'SimulatorObjectsLibrary::CQueue']]],
  ['next',['Next',['../class_simulator_objects_library_1_1_event.html#a341f07ce797c281d0f3e8d52fecf8ca5',1,'SimulatorObjectsLibrary::Event::Next()'],['../class_traffic_model_objects_library_1_1_vehicle_class.html#a2ff4ab0c4fe05e2ebe1fa8539bd3816b',1,'TrafficModelObjectsLibrary::VehicleClass::Next()']]],
  ['nextphasechangescheduledevent',['NextPhaseChangeScheduledEvent',['../class_traffic_model_objects_library_1_1_traffic_node_class.html#a00f6da1593844532b280db3e6fad3e79',1,'TrafficModelObjectsLibrary::TrafficNodeClass']]],
  ['nodescount',['NodesCount',['../class_traffic_model_objects_library_1_1_traffic_model_class.html#aaf8224c875642df369ec2976d87c5b40',1,'TrafficModelObjectsLibrary::TrafficModelClass']]],
  ['null',['NULL',['../_traffic_model_object_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'TrafficModelObject.h']]]
];
