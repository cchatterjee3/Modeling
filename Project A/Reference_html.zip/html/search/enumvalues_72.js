var searchData=
[
  ['remainder',['REMAINDER',['../namespace_simulator_objects_library.html#a3a5908120eaff5f92d18054402600b94a4f6598ad019db83bf1e338092b5e92e8',1,'SimulatorObjectsLibrary']]],
  ['roadsegment',['ROADSEGMENT',['../namespace_traffic_model_objects_library.html#a536f1e1adbd3bc9bf06bcf717d223ddfa69fd92736032048b00ef9ea836427fa2',1,'TrafficModelObjectsLibrary']]]
];
