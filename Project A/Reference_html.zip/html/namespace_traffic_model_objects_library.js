var namespace_traffic_model_objects_library =
[
    [ "DestinationClass", "class_traffic_model_objects_library_1_1_destination_class.html", null ],
    [ "IntersectionClass", "class_traffic_model_objects_library_1_1_intersection_class.html", null ],
    [ "ParkingLotClass", "class_traffic_model_objects_library_1_1_parking_lot_class.html", null ],
    [ "PhaseClass", "class_traffic_model_objects_library_1_1_phase_class.html", null ],
    [ "RoadSegmentClass", "class_traffic_model_objects_library_1_1_road_segment_class.html", null ],
    [ "TrafficModelClass", "class_traffic_model_objects_library_1_1_traffic_model_class.html", null ],
    [ "TrafficModelObject", "class_traffic_model_objects_library_1_1_traffic_model_object.html", null ],
    [ "TrafficNodeClass", "class_traffic_model_objects_library_1_1_traffic_node_class.html", null ],
    [ "VehicleClass", "class_traffic_model_objects_library_1_1_vehicle_class.html", null ],
    [ "VehicleQueueClass", "class_traffic_model_objects_library_1_1_vehicle_queue_class.html", null ],
    [ "ObjectType", "namespace_traffic_model_objects_library.html#a536f1e1adbd3bc9bf06bcf717d223ddf", null ],
    [ "HEADWAY_TIME_LB", "namespace_traffic_model_objects_library.html#a99bb75b0fed968f1d908419eddc88175", null ],
    [ "HEADWAY_TIME_UB", "namespace_traffic_model_objects_library.html#a4f91f30686691c6d13f7fe3e9e094f30", null ],
    [ "TAKEOFF_TIME_LB", "namespace_traffic_model_objects_library.html#ac04f7d926ab927de79f4936a28cbeb31", null ],
    [ "TAKEOFF_TIME_UB", "namespace_traffic_model_objects_library.html#a453e689cb3ec1341dd611eadf874e987", null ],
    [ "TIME_ERROR_LB", "namespace_traffic_model_objects_library.html#accbc49708036d981f86599c3f96cc8f1", null ],
    [ "TIME_ERROR_UB", "namespace_traffic_model_objects_library.html#ae49bbfd8a49fd9fb7bfa2fed73c1b233", null ]
];