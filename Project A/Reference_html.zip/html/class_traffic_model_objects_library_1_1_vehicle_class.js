var class_traffic_model_objects_library_1_1_vehicle_class =
[
    [ "VehicleClass", "class_traffic_model_objects_library_1_1_vehicle_class.html#a91230fc8beb984020ab69b9d99e70ea9", null ],
    [ "VehicleClass", "class_traffic_model_objects_library_1_1_vehicle_class.html#a9fcc04436c9eb2454156e3ca79217c79", null ],
    [ "~VehicleClass", "class_traffic_model_objects_library_1_1_vehicle_class.html#ac0ef94a96ffde1e64d17d107628119c3", null ],
    [ "getDestination", "class_traffic_model_objects_library_1_1_vehicle_class.html#ad53346c45fb452bffac4695ae3f8e86f", null ],
    [ "getStartTime", "class_traffic_model_objects_library_1_1_vehicle_class.html#a14fe64e0cdd3d42f6a23a64533567d6a", null ],
    [ "getTravelTime", "class_traffic_model_objects_library_1_1_vehicle_class.html#ad8cdccafa7efe7146c0f0ff25e94dd74", null ],
    [ "Next", "class_traffic_model_objects_library_1_1_vehicle_class.html#a2ff4ab0c4fe05e2ebe1fa8539bd3816b", null ],
    [ "Release", "class_traffic_model_objects_library_1_1_vehicle_class.html#ae5fb4c6671f97f4514222ffd74d8ff3c", null ],
    [ "setNext", "class_traffic_model_objects_library_1_1_vehicle_class.html#a04923dc1733da3224bc4a83d1ab9ff85", null ],
    [ "setStartTime", "class_traffic_model_objects_library_1_1_vehicle_class.html#ad3992290cdcd8d6c3541af705184c1de", null ],
    [ "setTravelTime", "class_traffic_model_objects_library_1_1_vehicle_class.html#afe23626885e5905aad0b0ab689bfacc6", null ],
    [ "ToString", "class_traffic_model_objects_library_1_1_vehicle_class.html#a12514663e569ca4b115ce5eaa09e04b0", null ],
    [ "mDestination", "class_traffic_model_objects_library_1_1_vehicle_class.html#ae2cc19ceb85af5cd3e6c3d25e816eeb2", null ],
    [ "mID", "class_traffic_model_objects_library_1_1_vehicle_class.html#a30c75c2254e197372aec49cb152e0974", null ],
    [ "mIssuedBy", "class_traffic_model_objects_library_1_1_vehicle_class.html#a141b3f96cdc692c1fcfe293a603d5a5b", null ],
    [ "mNext", "class_traffic_model_objects_library_1_1_vehicle_class.html#a00790fd2df5c2b4ab1fc63ecc09141e4", null ],
    [ "mStartTime", "class_traffic_model_objects_library_1_1_vehicle_class.html#aff0043e4a4264b046568e4453126c7b7", null ],
    [ "mTrafficModel", "class_traffic_model_objects_library_1_1_vehicle_class.html#a389ea366805a94660bbccb958275a731", null ],
    [ "mTravelTime", "class_traffic_model_objects_library_1_1_vehicle_class.html#a128eb5c36799463e58a94ee3ff9b21a3", null ]
];