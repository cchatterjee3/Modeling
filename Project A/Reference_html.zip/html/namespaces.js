var namespaces =
[
    [ "SimulatorObjectsLibrary", "namespace_simulator_objects_library.html", "namespace_simulator_objects_library" ],
    [ "TrafficModelEventLibrary", "namespace_traffic_model_event_library.html", "namespace_traffic_model_event_library" ],
    [ "TrafficModelObjectsLibrary", "namespace_traffic_model_objects_library.html", "namespace_traffic_model_objects_library" ]
];