var class_traffic_model_objects_library_1_1_destination_class =
[
    [ "DestinationClass", "class_traffic_model_objects_library_1_1_destination_class.html#a7c9fcd09b8266bba5166ac04b2cb3ba8", null ],
    [ "DestinationClass", "class_traffic_model_objects_library_1_1_destination_class.html#af302f0582c86424ed048fa110c96d175", null ],
    [ "~DestinationClass", "class_traffic_model_objects_library_1_1_destination_class.html#a12a67db5be200e2ca90833c8677b64bb", null ],
    [ "GetAverageTime", "class_traffic_model_objects_library_1_1_destination_class.html#a9466d539afb57f415b5cdca4b5cdea4b", null ],
    [ "GetCummulativeTime", "class_traffic_model_objects_library_1_1_destination_class.html#a30c32fc1d9be77a8e9e9e0384ecc495b", null ],
    [ "GetVehicleQueueOut", "class_traffic_model_objects_library_1_1_destination_class.html#a9d77e8f04f9d24a232efe321e9e5c85a", null ],
    [ "GetVehiclesServed", "class_traffic_model_objects_library_1_1_destination_class.html#ac64403132ed4ad3a502a5bb98ef24575", null ],
    [ "SetToStart", "class_traffic_model_objects_library_1_1_destination_class.html#a6ca94e012e52f0bcec828a1c180a81c9", null ],
    [ "VehicleIn", "class_traffic_model_objects_library_1_1_destination_class.html#a50e4ee7c998ebb9814afef178468027d", null ],
    [ "VehicleQueueOutIsFull", "class_traffic_model_objects_library_1_1_destination_class.html#a91f4c1d7f5e69cf789b8ca6919497778", null ],
    [ "mAverageCrossingTime", "class_traffic_model_objects_library_1_1_destination_class.html#a22c06bcee840972c9e2d4c3c51e6b79d", null ],
    [ "mCummulativeTime", "class_traffic_model_objects_library_1_1_destination_class.html#a760cb5c1601316a9ef0989c9dd40b11e", null ],
    [ "mVehiclesServed", "class_traffic_model_objects_library_1_1_destination_class.html#a332c1c4baf0d6cb453ae035cc7574f6f", null ]
];