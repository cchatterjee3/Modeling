#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"

namespace TrafficModelObjectsLibrary
{

/// <summary>	Default constructor. </summary>
VehicleQueueClass::VehicleQueueClass(void)
{
	mVehiclesReady = 0;
	mVehiclesinQueue = 0;
	mVehicleReadyFront = nullptr;
	mVehicleReadyLast = nullptr;
}


/// <summary>	Destructor. </summary>
VehicleQueueClass::~VehicleQueueClass(void)
{
}

/// <summary>	Gets the vehicles ready. </summary>
///
/// <returns>	. </returns>
int VehicleQueueClass::VehiclesReady()
{
	return mVehiclesReady;
}

/// <summary>	Gets the capacity. </summary>
///
/// <returns>	. </returns>
int VehicleQueueClass::Capacity()
{
	return mCapacity;
}

/// <summary>	Gets the exits. </summary>
///
/// <returns>	. </returns>
int VehicleQueueClass::Exits()
{
	return mExits;
}

/// <summary>	Determines if we can front row clear. </summary>
///
/// <returns>	true if it succeeds, false if it fails. </returns>
bool VehicleQueueClass::FrontRowClear(void)
{
	if (mVehiclesReady < mExits)
	{
		return true;
	}
	else
	{
		return false;
	}
}

/// <summary>
/// Adds a vehicle to the VehicleQueue if the queue has space. If not, an event is scheduled
/// latert on to add the vehicle.
/// </summary>
///
/// <param name="Vehicle">	[in,out] If non-null, the vehicle. </param>
void VehicleQueueClass::AddVehicleReady(VehicleClass* Vehicle)
{
	if (mVehiclesReady == 0)
	{
		mVehicleReadyFront = Vehicle;
		mVehicleReadyLast = Vehicle;
		Vehicle->setNext(nullptr);
		mVehiclesReady++;
	}
	else
	{
		mVehicleReadyLast->setNext(Vehicle);
		mVehicleReadyLast = Vehicle;
		mVehiclesReady++;
	}
}

/// <summary>	Returns the end traffic node of a VehicleQueue. </summary>
///
/// <returns>	null if it fails. </returns>
TrafficNodeClass * VehicleQueueClass::EndTrafficNode(void)
{
		return ptrEndTrafficNode;
}

	/// <summary>Gets a pointer to the current phase (object) of the VehicleQueue</summary>
	///
	/// <returns>null if it fails, else.</returns>
PhaseClass* VehicleQueueClass::Phase(void)
{
		return mPhase;
}

/// <summary>	Query if this object is full. </summary>
///
/// <returns>	true if full, false if not. </returns>
bool VehicleQueueClass::IsFull(void)
{
    if (mVehiclesinQueue == mCapacity)
    {
        return true;
                
    }
    else
    { 
	return false;
}
   
}

/// <summary>	Gets an intersection crossing time. </summary>
///
/// <param name="Destination">	Destination for the Vehicle. </param>
///
/// <returns>	The intersection crossing time. </returns>
double VehicleQueueClass::GetIntersectionCrossingTime(int Destination)
{
    for (int i=0; i <mDestinations; i++)
    {
        if (Destination==mDestinationIDs[i])
        {
            return mIntersectionCrossingTime[i];
        }
    }
        
	return 0; //Need to add error message here
}

/// <summary>	Query if 'Destination' is valid destination. </summary>
///
/// <param name="Destination">	Destination for the Vehicle. </param>
///
/// <returns>	true if valid destination, false if not. </returns>
bool VehicleQueueClass::IsValidDestination(int Destination) //Look back at this
{
    for (int i=0; i <mDestinations; i++)
    {
        if (Destination==mDestinationIDs[i])
        {
            return true;
        }
    }
	return false;
}

/// <summary>	Query if this object has vehicles ready. </summary>
///
/// <returns>	true if vehicles ready, false if not. </returns>
bool VehicleQueueClass::HasVehiclesReady(void)
{
	if (mVehiclesReady > 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

/// <summary>	Sets a destination for the VehicleQueue. </summary>
///
/// <param name="Index">				   	Zero-based index of destination. </param>
/// <param name="DestinationID">		   	Identifier for the destination. </param>
/// <param name="IntersectionCrossingTime">	Time of the intersection crossing. </param>
void VehicleQueueClass::SetDestination(int Index, int DestinationID, double IntersectionCrossingTime) //Look back for Index use
{
    mDestinationIDs[mDestinationCount]=DestinationID;
    mIntersectionCrossingTime[mDestinationCount]=IntersectionCrossingTime;
    mDestinationCount++;
    
}

/// <summary>	VehicleIn. </summary>
///
/// <param name="Vehicle">	[in,out] If non-null, the vehicle. </param>
void VehicleQueueClass::VehicleIn(VehicleClass *Vehicle)
{
    mVehiclesinQueue++;
}

/// <summary>	Gets the next vehicle destination. </summary>
///
/// <returns>	The next vehicle destination. </returns>
int VehicleQueueClass::GetNextVehicleDestination(void)
{
	if (mVehicleReadyFront)
	{
		return mVehicleReadyFront->getDestination();
	}
	else
	{
		return 0; // Need to handle error
	}
}

/// <summary>	Gets the average travel time. </summary>
///
/// <returns>	The average travel time. </returns>
double VehicleQueueClass::GetAverageTravelTime(void)
{
	return mAverageTravelTime;
}
}
