#pragma once
using namespace SimulatorObjectsLibrary;
using namespace TrafficModelObjectsLibrary;

namespace TrafficModelEventLibrary
{

/// <summary>Seek vehicle event.</summary>
class SeekVehicleEvent:
	public TrafficModelEvent
{
protected:
	/// <summary>The intersection.</summary>
	IntersectionClass* mIntersection;
	/// <summary>The vehicle queue in.</summary>
	VehicleQueueClass*  mVehicleQueueIn;
public:
	/// <summary>Initializes a new instance of the SeekVehicleEvent class.</summary>
	SeekVehicleEvent(void);
	/// <summary>Finalizes an instance of the SeekVehicleEvent class.</summary>
	~SeekVehicleEvent(void);

	/// <summary>Initializes a new instance of the SeekVehicleEvent class.</summary>
	///
	/// <param name="Intersection">  	[in,out] If non-null, the intersection.</param>
	/// <param name="VehicleQueueIn">	[in,out] If non-null, the vehicle queue in.</param>
	/// <param name="EventTime">	 	Time of the event.</param>

	SeekVehicleEvent(IntersectionClass* Intersection, VehicleQueueClass* VehicleQueueIn, double EventTime);

	/// <summary>Runs this object.</summary>
	virtual void Run(void);

	virtual void Release(void);
};

}
