#pragma once
using namespace SimulatorObjectsLibrary;
using namespace TrafficModelObjectsLibrary;

namespace TrafficModelEventLibrary
{

/// <summary>VehicleAtFronEvent Class</summary>
class VehicleAtFrontEvent:
	public TrafficModelEvent
{
protected:
	/// <summary>Queue of VehicleQueueClass objects</summary>
	VehicleQueueClass* mVehicleQueue;
	/// <summary>VehicleClass object</summary>
	VehicleClass* mVehicle;
public:
	/// <summary>Initializes a new instance of the VehicleAtFrontEvent class.</summary>
	VehicleAtFrontEvent(void);

	/// <summary>Initializes a new instance of the VehicleAtFrontEvent class.</summary>
	///
	/// <param name="VehicleQueue">	[in,out] If non-null, queue of vehicles.</param>
	/// <param name="Vehicle">	   	[in,out] If non-null, the vehicle.</param>
	/// <param name="EventTime">   	Time of the event.</param>

	VehicleAtFrontEvent(VehicleQueueClass* VehicleQueue, VehicleClass* Vehicle, double EventTime);
	/// <summary>Destructor for VehicleAtFrontEvent class.</summary>
	~VehicleAtFrontEvent(void);

	/// <summary>Execute the VehicleAtFrontEvent object.</summary>
	virtual void Run(void);
	virtual void Release(void);
};

}
