/* 
 * File:   random.h
 * Author: MaryBenage
 *
 * Created on February 12, 2012, 2:12 PM
 */

namespace SimulatorObjectsLibrary
{

/// <summary>Values that represent RGNConstants.</summary>
enum RGNConstants
{
	MODULUS	   = 2147483647,  //CONSTANT
	MULTIPLIER =      48271,  //CONSTANT
	QUOTIENT   =      44488,  //CONSTANT
	REMAINDER  =       3399,  //CONSTANT
	TEST_SEED  = 1234569832   //For testing only
};

/// <summary>Random Generator Class. This object will provide random number uniformily distributed.</summary>
class clsRandomGenerator
{
	protected:
		/// <summary>The long to process.</summary>
		long t;    
		
		/// <summary>The seed.</summary>
		long seed;
	
    private:

		/// <summary>Gets the lehmer random.</summary>
		///
		/// <returns>.</returns>

		double Lehmer_Random(void);

    public:
        /// <summary>Initializes a new instance of the clsRandomGenerator class.</summary>
		clsRandomGenerator(void){seed = TEST_SEED;}

		/// <summary>Initializes a new instance of the clsRandomGenerator class.</summary>
		///
		/// <param name="Seed">	The seed.</param>
		clsRandomGenerator(long Seed){seed = Seed;}
		
		/// <summary>Finalizes an instance of the clsRandomGenerator class.</summary>
		~clsRandomGenerator(void){};

		/// <summary>Uniform distance.</summary>
		///
		/// <param name="a">	Lower bound of the interval.</param>
		/// <param name="b">	Upper bound of the interval.</param>
		///
		/// <returns>.</returns>

		double UniformDist(double a, double b); //Input of distribution of times with a < b

        /// <summary>Int uniform distance.</summary>
        ///
        /// <param name="a">	Lower bound of the interval.</param>
        /// <param name="b">	Upper bound of the interval.</param>
        ///
        /// <returns>.</returns>

        int intUniformDist(int a, int b);

		/// <summary>Tests the Random Number Generator using the Chi-test.</summary>
		///
		/// <param name="samples">	input the number of samples, number of samples must be 1,000 or more.</param>
		/// <param name="numbins">	input the number of bins, number of bins should be 100 or more.</param>
		///
		/// <returns>.The Chi value to compare to a table </returns>

		double Chi_test(int samples, int numbins);

};
}
