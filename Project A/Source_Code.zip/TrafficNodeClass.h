#pragma once
using namespace SimulatorObjectsLibrary;

namespace TrafficModelObjectsLibrary
{


/// <summary>TrafficNodeClass Object</summary>
class TrafficNodeClass:
	public TrafficModelObject
{
protected:
	/// <summary>Counter for the Number of phases in the TrafficModel object.</summary>
	int mPhasesCount;
	/// <summary>Maximum number of phases</summary>
	int mPhasesMax;
	/// <summary>Pointer to an array of PhaseClass objects</summary>
	PhaseClass ** mPhasesList;

	/// <summary>The index of the active phase</summary>
	unsigned int mActivePhaseIndex;

	/// <summary>The number of vehicles coming into the TrafficNode object</summary>
	int mVehiclesIn;

	/// <summary>The vehicle queues out.</summary>
	int mVehicleQueuesOut;
    /// <summary>The number of VehicleQueues outgoing to the intersection</summary>
    int mVehicleQueuesOutCount;
	/// <summary>Pointer to an array of the VehicleQueues outgoing to the intersection</summary>
	TrafficModelObject ** mVehicleQueuesOutList;
	/// <summary>Pointer to the TrafficModel object</summary>
	TrafficModelObject* mTrafficModel;

	/// <summary>Flag indicating the status of the Intersection</summary>
	bool mIdle;
	/// <summary>Event queue for all listeners interested in NextPhaseChangeScheduled events.</summary>
	Event * mNextPhaseChangeScheduledEvent;

	/// <summary>List of indicies of all incoming queues to the intersection</summary>
	int mIndexInList;

public:

	/// <summary>Initializes a new instance of the TrafficNodeClass class.</summary>
	TrafficNodeClass(void);

	/// <summary>Finalizes an instance of the TrafficNodeClass class.</summary>
	~TrafficNodeClass(void);

	/// <summary>Get a pointer to the TrafficModel object</summary>
	///
	/// <returns>null if it fails, else.</returns>

	TrafficModelObject* TrafficModel(void);

	/// <summary>Gets the phases count of an intersection</summary>
	///
	/// <returns>Integer - Number of phases of an intersection</returns>

	int PhasesCount(void);

	/// <summary>Gets the index of the active phase of an intersection</summary>
	///
	/// <returns>Integer.</returns>

	int ActivePhaseIndex(void);

	/// <summary>Gets a pointer to the active phase object.</summary>
	///
	/// <returns>null if it fails</returns>

	PhaseClass* ActivePhase(void);

	/// <summary>Gets a phase object at location "index"</summary>
	///
	/// <param name="Index">	Zero-based index of the Phase objects</param>
	///
	/// <returns>null if it fails, else the phase.</returns>

	PhaseClass* GetPhase(int Index);

    /// <summary>
    /// Changes the Active Phase and returns the Time when the next phase change must occur.
    /// </summary>
    ///
    /// <returns>	Time of duration of the phase. </returns>
    double ChangePhase(void);

	/// <summary>Query if this object is idle.</summary>
	///
	/// <returns>true if idle, false if not.</returns>

	bool IsIdle(void);

	/// <summary>Query if this object is empty.</summary>
	///
	/// <returns>true if empty, false if not.</returns>

	bool IsEmpty(void);

	/// <summary>Gets the next phase change scheduled event.</summary>
	///
	/// <returns>null if it fails, else.</returns>

	Event * NextPhaseChangeScheduledEvent(void);

	/// <summary>Sets a next phase change scheduled event.</summary>
	///
	/// <param name="ptrEvent">	[in,out] If non-null, the pointer event.</param>

	void SetNextPhaseChangeScheduledEvent(Event* ptrEvent);

	/// <summary>Sets an active phase.</summary>
	///
	/// <param name="Index">	Zero-based index of the.</param>
	///
	/// <returns>.</returns>

	double SetActivePhase(int Index);

	/// <summary>Sets the next active phase.</summary>
	///
	/// <returns>.</returns>

	double SetNextActivePhase(void);

	/// <summary>	Vehicle in. </summary>
	void VehicleIn(void);
	
	/// <summary>Vehicle out.</summary>
	void VehicleOut(void);

	/// <summary>Gets a vehicle queue out.</summary>
	///
	/// <param name="Destination">	Destination for the.</param>
	///
	/// <returns>null if it fails, else the vehicle queue out.</returns>

	virtual TrafficModelObject * GetVehicleQueueOut(int Destination)=0; //Done

	virtual void SetToStart(void)=0;

	/// <summary>Gets the vehicle queues out count.</summary>
	///
	/// <returns>.</returns>

	int VehicleQueuesOutCount(void);

	/// <summary>Adds a vehicle queue out.</summary>
	///
	/// <param name="QueueOut">	[in,out] If non-null, the queue out.</param>

	void AddVehicleQueueOut(TrafficModelObject* QueueOut);

	/// <summary>Vehicle in.</summary>
	///
	/// <param name="Vehicle">	[in,out] If non-null, the vehicle.</param>

	virtual void VehicleIn(VehicleClass* Vehicle)=0;

	/// <summary>Vehicle queue out is full.</summary>
	///
	/// <param name="Destination">	Destination for the.</param>
	///
	/// <returns>true if it succeeds, false if it fails.</returns>

	virtual bool VehicleQueueOutIsFull(int Destination)=0;
};

}

