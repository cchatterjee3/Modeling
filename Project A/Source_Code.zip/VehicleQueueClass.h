#pragma once

namespace TrafficModelObjectsLibrary
{

/// <summary>Vehicle queue class.</summary>
class VehicleQueueClass:
	public TrafficModelObject
{
protected:

	/// <summary>ffic model object. Acts as a container for other simulation objects like Vehicles</summary>
	TrafficModelObject* mTrafficModel;
	/// <summary>Number of vehicle in a queue (road) at the current instant</summary>
	int mVehiclesinQueue;
	/// <summary>Number of vehicles ready to be processed off the queue</summary>
	int mVehiclesReady;
	/// <summary>Capacity (in vehicles) of the VehicleQueue.</summary>
	int mCapacity;
	/// <summary>The number of exits of a vehicle queue</summary>
	int mExits;
	/// <summary>The number of destinations that a VehicleQueue serves.</summary>
	int mDestinations;
	/// <summary>A pointer to an array of Destination IDs that are served by the VehicleQueue</summary>
	int * mDestinationIDs;
    /// <summary>The number of destinations that the queue(road) serves</summary>
    int mDestinationCount;
	/// <summary>Average crossing time of the Intersection</summary>
	double * mIntersectionCrossingTime;
	/// <summary>Average time that it takes a vehicle to travel the length of the road</summary>
	double mAverageTravelTime;
	/// <summary>The number of vehicles that are ready at the front of the queue to be processed</summary>
	VehicleClass *mVehicleReadyFront;
	/// <summary>The number of vehicles that are "ready" at the end of the queue.</summary>
	VehicleClass *mVehicleReadyLast;
	
    /// <summary>ID of the ending traffic node that is incident to the VehicleQueue</summary>
    int mEndTrafficNodeIndex;
	/// <summary>A pointer to the ending traffic node (incident to the VehicleQueue)</summary>
	TrafficNodeClass* ptrEndTrafficNode;
    /// <summary>Indicator of the current phase (starts from zero)</summary>
    int mPhaseIndex;
	/// <summary>A pointer to the phase of the VehicleQueue</summary>
	PhaseClass * mPhase;

	/// <summary>List of index ins.</summary>
	int mIndexInList;

public:

	/// <summary>Initializes a new instance of the VehicleQueueClass class.</summary>
	VehicleQueueClass(void);

	/// <summary>Finalizes an instance of the VehicleQueueClass class.</summary>
	~VehicleQueueClass(void);

	/// <summary>VehicleOut</summary>
	///
	/// <param name="Time">	The time.</param>
	///
	/// <returns>Method that processes a vehicle at time=Time.</returns>

	virtual VehicleClass *VehicleOut(double Time)=0;

	virtual void SetToStart(void)=0;

	/// <summary>VehicleIn</summary>
	///
	/// <param name="Vehicle">	[in,out] If non-null, the vehicle.</param>

	void VehicleIn(VehicleClass *Vehicle);

	/// <summary>Gets the vehicles ready.</summary>
	///
	/// <returns>.</returns>

	int VehiclesReady(void);

	/// <summary>Gets the exits.</summary>
	///
	/// <returns>.</returns>

	int Exits(void);

	/// <summary>Check the number of exits of a VehicleQueue object</summary>
	///
	/// <returns>Integer representing number of exits of a VehicleQueue</returns>

	int Capacity(void);

	/// <summary>Checks whether the head of the queue is clear</summary>
	///
	/// <returns>true if clear, false if not clear.</returns>

	bool FrontRowClear(void);

	/// <summary>Sets a destination for the VehicleQueue</summary>
	///
	/// <param name="Index">				   	Zero-based index of destination</param>
	/// <param name="DestinationID">		   	Identifier for the destination.</param>
	/// <param name="IntersectionCrossingTime">	Time of the intersection crossing.</param>

	void SetDestination(int Index, int DestinationID, double IntersectionCrossingTime);

	/// <summary>Adds a vehicle to the VehicleQueue if the queue has space. If not, an event is scheduled latert on to add the vehicle</summary>
	///
	/// <param name="Vehicle">	[in,out] If non-null, the vehicle.</param>

	void AddVehicleReady(VehicleClass* Vehicle);

	/// <summary>Returns the end traffic node of a VehicleQueue</summary>
	///
	/// <returns>null if it fails</returns>

	TrafficNodeClass * EndTrafficNode(void);

	/// <summary>Gets a pointer to the current phase (object) of the VehicleQueue</summary>
	///
	/// <returns>null if it fails, else.</returns>

	PhaseClass* Phase(void);

	/// <summary>Query if this VehicleQueue objeect is full.</summary>
	///
	/// <returns>true if full, false if not.</returns>

	bool IsFull(void);

	/// <summary>Gets an intersection crossing time.</summary>
	///
	/// <param name="Destination">	Destination for the Vehicle</param>
	///
	/// <returns>The intersection crossing time.</returns>

	double GetIntersectionCrossingTime(int Destination);

	/// <summary>Query if 'Destination' is valid destination.</summary>
	///
	/// <param name="Destination">	Destination for the Vehicle</param>
	///
	/// <returns>true if valid destination, false if not.</returns>

	bool IsValidDestination(int Destination);

	/// <summary>Query if this VehicleQueue object has vehicles ready.</summary>
	///
	/// <returns>true if vehicles ready, false if not.</returns>

	bool HasVehiclesReady(void);

	/// <summary>Gets the next vehicle destination.</summary>
	///
	/// <returns>The next vehicle destination.</returns>

	int GetNextVehicleDestination(void);

	/// <summary>Gets the average travel time.</summary>
	///
	/// <returns>Double representing the average travel time.</returns>

	double GetAverageTravelTime(void);

	/// <summary>Gets the index in list.</summary>
	///
	/// <returns>Integer represting the object's index in the list.</returns>

	int IndexInList(void){return mIndexInList;}
};
}

