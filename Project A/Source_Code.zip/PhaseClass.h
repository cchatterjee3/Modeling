#pragma once
using namespace SimulatorObjectsLibrary;

namespace TrafficModelObjectsLibrary
{
	
/// <summary>Phase class.</summary>
class PhaseClass:
    public TrafficModelObject
{
protected:

    /// <summary>The number of vehicle queues delivering vehicles to the intersection.</summary>
    int mVehicleQueuesIn;
	
	/// <summary>Counter for the number of vehicle queues in.</summary>
	int mVehicleQueuesInCount;
	
	/// <summary>List of pointers to the vehicles queues delivering vehicles to the intersection.</summary>
	TrafficModelObject ** mVehicleQueuesInList;
	
	/// <summary> Show the state of the phase.</summary>
	bool mActive;
	
	/// <summary> The interval of time at which the phase is going to run.</summary>
	double mAverageServiceTime;
    
	/// <summary>The index in the phases pointers list of the node.</summary>
        int mIndexInNode;

public:

	/// <summary>Initializes a new instance of the PhaseClass class.</summary>
	PhaseClass(void); //Done

	/// <summary>	Initializes a new instance of the PhaseClass class. </summary>
	///
	/// <param name="Index">		 	Index of the pointer to this Phase in the pointers to phases
	/// 								list in the intersection . </param>
	/// <param name="QueuesIn">		 	The number of vehicle queues that are being served by the
	/// 								phase. </param>
	/// <param name="AvgServiceTime">	The interval of time at which the phase is going to run. </param>
	PhaseClass(int Index, int QueuesIn, double AvgServiceTime); //Attempted by M
	
	/// <summary>Finalizes an instance of the PhaseClass class.</summary>
	~PhaseClass(void); 

	/// <summary>Adds the given vehicle queue in to vehicles queues in list of the phase.</summary>
	///
	/// <param name="QueueIn"> Vehicle queue  being added to th elist to pointers list of the vehicle queue.</param>
	void AddVehicleQueueIn(TrafficModelObject* QueueIn); //Attempted by M


	/// <summary>Gets the vehicle queue in at the given index in the phases vehicle queues in list.</summary>
	///
	/// <param name="Index">	Index of the pointer.</param>
	///
	/// <returns>null if it fails, else pointer to the vehicle queue in requested.</returns>
	TrafficModelObject * GetVehicleQueueIn(int Index); //Done

	/// <summary>Gets the average service time for the current phase.</summary>
	///
	/// <returns>The average service time.</returns>
	double GetAverageServiceTime(void); //Done

    /// <summary>Gets the index of the node (destination or intersection) which contains the phase.</summary>
    ///
    /// <returns>The index in node.</returns>
	int GetIndexInNode(void);

	/// <summary>Gets the number of vehicle queues being serve by the Phase.</summary>
	///
	/// <returns>The vehicle queues in.</returns>
	int GetVehicleQueuesIn(void);

	/// <summary>Gets count of vehicles queues in the phase.</summary>
	///
	/// <returns>The vehicle queues in count.</returns>
	int GetVehicleQueuesInCount(void);

	bool HasVehiclesReady(void);
	
};

}

