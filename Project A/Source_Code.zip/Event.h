#pragma once
#ifndef NULL
#define NULL 0
#endif
namespace SimulatorObjectsLibrary
{

/// <summary>Event.</summary>
class Event
{
protected:
	/// <summary>Time of the event.</summary>
	double mEventTime;
	/// <summary>This member is used to facilitate the use of linked lists. This is a pointer to the next event in the linked list.</summary>
	Event* mNext;
public:
	/// <summary>Initializes a new instance of the Event class.</summary>
	Event(void);
	/// <summary>Finalizes an instance of the Event class.</summary>
	~Event(void);

	/// <summary>Gets the event time.</summary>
	///
	/// <returns>.The event time.</returns>
	double EventTime(void);

	/// <summary>Gets the pointer to the next even in the linked list.</summary>
	///
	/// <returns>null if it there is not a next event, else a pointer to the linked list.</returns>
	Event* Next(void);

	/// <summary>Set the pointer to the next event.</summary>
	///
	/// <param name="nextEvent">	The next event.</param>
	void SetNext(Event* nextEvent);

	/// <summary>Runs this event.</summary>
	virtual void Run(void)=0;

	/// <summary>Sets event time.</summary>
	///
	/// <param name="EventTime">	Time of the event.</param>
	void SetEventTime(double EventTime);

};
}
