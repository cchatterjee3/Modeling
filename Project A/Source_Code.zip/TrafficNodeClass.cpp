
#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"

namespace TrafficModelObjectsLibrary
{

/// <summary>	Default constructor. </summary>
TrafficNodeClass::TrafficNodeClass(void)
{
}


/// <summary>	Destructor. </summary>
TrafficNodeClass::~TrafficNodeClass(void)
{
}

/// <summary>	Changes the Active Phase and returns the Time when the next phase change must occur. </summary>
///
/// <returns>	Time of duration of the phase. </returns>
double TrafficNodeClass::ChangePhase(void)
{
	if (!this->IsIdle())
	{
		do
		{
			mActivePhaseIndex++;
			if (mActivePhaseIndex > mPhasesCount-1 )
		    {
			   mActivePhaseIndex = 0;
		    }
		} while (!mPhasesList[mActivePhaseIndex]->HasVehiclesReady());
	}
	
	return mPhasesList[mActivePhaseIndex]->GetAverageServiceTime();
}

/// <summary>	Query if this object is idle. </summary>
///
/// <returns>	true if idle, false if not. </returns>
bool TrafficNodeClass::IsIdle(void)
{	
	for(int i=0; i < mPhasesCount; i++)
	{
		for (int j=0; j < mPhasesList[i]->GetVehicleQueuesInCount(); j++)
		{
	         if (((VehicleQueueClass*)mPhasesList[i]->GetVehicleQueueIn(j))->HasVehiclesReady())
				 return false;
		}
	}
	return true;
}

/// <summary>	Gets the next phase change scheduled event. </summary>
///
/// <returns>	null if it fails, else. </returns>
Event *TrafficNodeClass::NextPhaseChangeScheduledEvent(void)
{
	return mNextPhaseChangeScheduledEvent;
}

/// <summary>	Sets a next phase change scheduled event. </summary>
///
/// <param name="ptrEvent">	[in,out] If non-null, the pointer event. </param>
void TrafficNodeClass::SetNextPhaseChangeScheduledEvent(Event* ptrEvent)
{
	mNextPhaseChangeScheduledEvent = ptrEvent;
}

/// <summary>
/// Sets a phase to active state and returns the time of duration of the phase.
/// </summary>
///
/// <param name="Index">	Zero-based index of the active phase. </param>
///
/// <returns>	Time of duration of the phase. </returns>
double TrafficNodeClass::SetActivePhase(int Index)
{

	if (Index >= mPhasesCount)
		Index = mPhasesCount - 1;

    mActivePhaseIndex = Index;
    return mPhasesList[Index]->GetAverageServiceTime();

}

/// <summary>	Sets the next phase to active state and returns the time of duration of the phase. </summary>
///
/// <returns>	Time of duration of the phase. </returns>
double TrafficNodeClass::SetNextActivePhase(void)
{
    if (mActivePhaseIndex == mPhasesCount)
	{
		mActivePhaseIndex = 0;
	}
	else
	{
		mActivePhaseIndex++;
	}

	return mPhasesList[mActivePhaseIndex]->GetAverageServiceTime();

}

/// <summary>	Gets the phases count. </summary>
///
/// <returns>	. </returns>
int TrafficNodeClass::PhasesCount(void)
{
    return mPhasesCount;
    
}

/// <summary>	Gets the active phase index. </summary>
///
/// <returns>	. </returns>
int TrafficNodeClass::ActivePhaseIndex(void)
        {
            return mActivePhaseIndex;
        }

/// <summary>	Gets the active phase. </summary>
///
/// <returns>	null if it fails, else. </returns>
PhaseClass* TrafficNodeClass::ActivePhase(void)
        {
            return mPhasesList[mActivePhaseIndex];
        }

/// <summary>	Gets a phase object at location "index". </summary>
///
/// <param name="Index">	Zero-based index of the Phase objects. </param>
///
/// <returns>	null if it fails, else the phase. </returns>
PhaseClass* TrafficNodeClass::GetPhase(int Index)
        {
            return mPhasesList[Index];
        }

/// <summary>	Gets the traffic model. </summary>
///
/// <returns>	null if it fails, else. </returns>
TrafficModelObject* TrafficNodeClass::TrafficModel(void)
{
	return mTrafficModel;
}

/// <summary>	Vehicle out. </summary>
void TrafficNodeClass::VehicleOut(void)
{
	mVehiclesIn--;
}

/// <summary>	Adds a vehicle queue out. </summary>
///
/// <param name="QueueOut">	[in,out] If non-null, the queue out. </param>
void TrafficNodeClass::AddVehicleQueueOut(TrafficModelObject* QueueOut)
{
    if (mVehicleQueuesOutCount < mVehicleQueuesOut)
    {
    mVehicleQueuesOutList[mVehicleQueuesOutCount] = QueueOut;
    mVehicleQueuesOutCount++;
    }
    
}

/// <summary>	Gets the vehicle queues out count. </summary>
///
/// <returns>	. </returns>
int TrafficNodeClass::VehicleQueuesOutCount(void)
{
	return mVehicleQueuesOutCount;
}

/// <summary>	Query if this object is empty. </summary>
///
/// <returns>	true if empty, false if not. </returns>
bool TrafficNodeClass::IsEmpty()
{
    if (mVehiclesIn == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

}
