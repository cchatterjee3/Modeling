#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"

#include "TrafficModelEvent.h"
#include "SeekVehicleEvent.h"
#include "PhaseChangeEvent.h"


namespace TrafficModelEventLibrary
{

/// <summary>	Default constructor. </summary>
PhaseChangeEvent::PhaseChangeEvent(void){}

/// <summary>	Constructor. </summary>
///
/// <param name="Intersection">	[in,out] If non-null, the intersection. </param>
/// <param name="EventTime">   	Time of the event. </param>
PhaseChangeEvent::PhaseChangeEvent(IntersectionClass* Intersection, double EventTime)
{
	mType = PHASE_CHANGE;
	mNext = nullptr;
	mEventTime = EventTime;
	mIntersection = Intersection;
}

/// <summary>	Destructor. </summary>
PhaseChangeEvent::~PhaseChangeEvent(void)
{
}

void PhaseChangeEvent::Release(void)
{
	mNext = nullptr;
	mIntersection = nullptr;
}

/// <summary>	Runs this Event. </summary>
void PhaseChangeEvent::Run(void)
{
	SimulatorClass * Simulator = ((TrafficModelClass*)mIntersection->TrafficModel())->Simulator();
	clsRandomGenerator * RandomGenerator =  ((TrafficModelClass*)mIntersection->TrafficModel())->RandomGenerator();
	double PhaseTime = mIntersection->ChangePhase();

	if(mIntersection->IsEmpty())
	{
	PhaseClass* currentPhase = mIntersection->ActivePhase();
	int numQueuesIn = currentPhase->GetVehicleQueuesInCount();
	int numLanes;

	for(int i=0; i < numQueuesIn; i++)
	{
		numLanes = ((VehicleQueueClass*)currentPhase->GetVehicleQueueIn(i))->Exits();
		double TakeOffTime;
		for (int j=0; j < numLanes; j++)
		{
			TakeOffTime = RandomGenerator->UniformDist(TAKEOFF_TIME_LB, TAKEOFF_TIME_UB);
			Simulator->AddEvent(new SeekVehicleEvent(mIntersection, (VehicleQueueClass*)currentPhase->GetVehicleQueueIn(i), mEventTime + TakeOffTime));
		}
	}
	}

	if(!mIntersection->IsIdle())
	{
		PhaseTime = RandomGenerator->UniformDist(TIME_ERROR_LB * PhaseTime, TIME_ERROR_UB * PhaseTime);
	    Event* NextPhaseChangeEvent = new PhaseChangeEvent(mIntersection, mEventTime + PhaseTime);
	    mIntersection->SetNextPhaseChangeScheduledEvent(NextPhaseChangeEvent);
	    Simulator->AddEvent(NextPhaseChangeEvent);
	}
	else
	{
         mIntersection->SetNextPhaseChangeScheduledEvent(nullptr);
	}
}

}
