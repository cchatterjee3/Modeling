#pragma once
using namespace SimulatorObjectsLibrary;
using namespace TrafficModelObjectsLibrary;

namespace TrafficModelEventLibrary
{

/// <summary>Phase change event.</summary>
class PhaseChangeEvent:
		public TrafficModelEvent
{
protected:
	/// <summary>pointer to the intersection at which this event occurs.</summary>
	IntersectionClass* mIntersection;
public:

	/// <summary>Initializes a new instance of the PhaseChangeEvent class.</summary>
	PhaseChangeEvent(void);

	/// <summary>Initializes a new instance of the PhaseChangeEvent class.</summary>
	///
	/// <param name="Intersection">	Pointer to the intersection where the event is going to occur.</param>
	/// <param name="EventTime">   	Time of the event.</param>
	PhaseChangeEvent(IntersectionClass* Intersection, double EventTime);

	/// <summary>Finalizes an instance of the PhaseChangeEvent class.</summary>
	~PhaseChangeEvent(void);

	/// <summary>Runs this event.</summary>
	virtual void Run(void);

	virtual void Release(void);
};
}

