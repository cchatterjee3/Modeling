#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"
#include "TrafficModelEvent.h"
#include "VehicleExitsIntersectionEvent.h"

using namespace TrafficModelEventLibrary;
namespace TrafficModelObjectsLibrary
{
/// <summary>Initializes a new instance of the IntersectionClass class.</summary>
IntersectionClass::IntersectionClass(void)
{
	mType = INTERSECTION;  
}

/// <summary>	Initializes a new instance of the IntersectionClass class. </summary>
///
/// <param name="Index">	   	Index of the intersection in the traffic node list. </param>
/// <param name="TrafficModel">	[in,out] pointer to the model. </param>
/// <param name="PhasesMax">   	The maximum number of phases for the current intersection. </param>
/// <param name="QueuesOut">   	The number of vehicle Queues going out of the intersection. </param>
IntersectionClass::IntersectionClass(int Index, TrafficModelObject * TrafficModel, int PhasesMax, int QueuesOut)
{
    mType = INTERSECTION;
	mTrafficModel = TrafficModel;
	mPhasesCount = 0;
	mVehiclesIn = 0;
	
	mPhasesMax = PhasesMax;
    mPhasesList = (PhaseClass**) malloc(sizeof(PhaseClass*)*PhasesMax); //mPhasesList  need to alocate PhasesCount time size of (PhaseClass*)

	mVehicleQueuesOut = QueuesOut;
	mVehicleQueuesOutCount = 0;
    mVehicleQueuesOutList = ((TrafficModelObject **) malloc (QueuesOut * sizeof(VehicleQueueClass *))); 

	mIdle = true;
	mActivePhaseIndex = 0;

	mIndexInList= Index;
	mNextPhaseChangeScheduledEvent = nullptr;
}

IntersectionClass::~IntersectionClass(void)
{
}

/// <summary>	Creates a phase and returns the pointer to it. </summary>
///
/// <param name="QueuesIn">			  	The number of queues delivering cars to the intersection
/// 									at the current phase. </param>
/// <param name="mAverageServiceTime">	Time of the average service. </param>
///
/// <returns>	null if it fails, returns pointers of current created phase. </returns>
PhaseClass* IntersectionClass::AddPhase( int QueuesIn, double mAverageServiceTime)
{
//Create a pointer to a new Phase called CurrentPhase
PhaseClass * CurrentPhase = new PhaseClass(mPhasesCount, QueuesIn,  mAverageServiceTime);
mPhasesList[mPhasesCount] = CurrentPhase;
mActivePhaseIndex = mPhasesCount;

// Increase the number of Phases already added to the list
mPhasesCount++;

// Return the pointer of the phase
return CurrentPhase;


}


/// <summary>
/// Gets the pointer at the given index in the pointer phases list of the intersection.
/// </summary>
///
/// <param name="Index">	Index of the pointer to the required phase. </param>
///
/// <returns>	null if it fails, else returns the pointer to the Phase. </returns>
PhaseClass* IntersectionClass::GetPhase(int Index)
{
    return mPhasesList[Index];
}

/// <summary>
/// Gets the vehicle queue going out of the intersection which serves the destination given.
/// </summary>
///
/// <param name="Destination">	Destination of the vehicle using the intersection. </param>
///
/// <returns>
/// null if it fails, else the pointer to the vehicle queue serving the given destination.
/// </returns>
TrafficModelObject * IntersectionClass::GetVehicleQueueOut(int Destination)
{
    for(int i = 0; i < mVehicleQueuesOutCount; i++)
            
    if (((VehicleQueueClass*)mVehicleQueuesOutList[i])->IsValidDestination( Destination))
		{
			return mVehicleQueuesOutList[i];
		}

	return NULL;
     }

/// <summary>	Adds the vehicle given to the intersection. </summary>
///
/// <param name="Vehicle">	[in,out] pointer to the vehicle reaching the intersection. </param>
void IntersectionClass::VehicleIn(VehicleClass* Vehicle)
{
	mVehiclesIn++;
	SimulatorClass* Simulator = ((TrafficModelClass*)mTrafficModel)->Simulator();
	VehicleQueueClass* VehicleQueueOut = (VehicleQueueClass*) this->GetVehicleQueueOut(Vehicle->getDestination());
	Simulator->AddEvent(new VehicleExitsIntersectionEvent(Vehicle, this, VehicleQueueOut, Vehicle->getTravelTime() ));

}

 /// <summary>
 /// Checks if the vehicle queue  going out of the intersection and serving the given destination
 /// is full.
 /// </summary>
 ///
 /// <param name="Destination">	Destination of the vehicle. </param>
 ///
 /// <returns>
 /// The full status of the vehicle queue serving the destination out of the current intersection.
 /// </returns>
 bool IntersectionClass::VehicleQueueOutIsFull(int Destination)
  {
	  return ((VehicleQueueClass*)this->GetVehicleQueueOut(Destination))->IsFull(); 
  }

 void IntersectionClass::SetToStart(void)
{
    mVehiclesIn = 0;
	mNextPhaseChangeScheduledEvent = nullptr;
	mIdle = true;
	mActivePhaseIndex = 0;
}

}


