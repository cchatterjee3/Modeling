#pragma once

namespace TrafficModelObjectsLibrary
{

/// <summary>	Destination class. </summary>
class DestinationClass :
	public TrafficNodeClass
{
protected:
	/// <summary>	The average crossing time for a vehicle. </summary>
	double mAverageCrossingTime;
        
	/// <summary>	A counter for the number of vehilces served. </summary>
	int mVehiclesServed;
        
    /// <summary>	Cummulative Time used to keep track of vehicle travel time. </summary>
    double mCummulativeTime;
public:

	/// <summary>Initializes a new instance of the Destination Class.</summary>
	DestinationClass(void){};

    /// <summary>Initializes a new instance of the Destination Class.</summary>
    ///
    /// <param name="Index">			Index of the destination in the traffic node list.</param>
    /// <param name="TrafficModel">		  	pointer to the Model.</param>
    /// <param name="AverageCrossingTime">	        Time of the average crossing.</param>
	DestinationClass(int Index, TrafficModelObject * TrafficModel, double  AverageCrossingTime);
	
	/// <summary>Finalizes an instance of the DestinationClass class.</summary>
	~DestinationClass(void){};

	/// <summary>Gets Number of vehicles served.</summary>
	///
	/// <returns>The number of the number of vehicles served in the Model.</returns>
	int GetVehiclesServed(void){return mVehiclesServed;}

    /// <summary>Gets the cummulative time of travel for the vehicle.</summary>
    ///
    /// <returns>The the cummulative travel time.</returns>
	double GetCummulativeTime(void){return mCummulativeTime;}

	/// <summary>Gets the average time.</summary>
	///
	/// <returns>The average time.</returns>
	double GetAverageTime(void);

	/// <summary>Gets the vehicle queue which serves the destination given.</summary>
	///
	/// <param name="Destination">	Destination of the vehicle.</param>
	///
	/// <returns> always null. there are no vehicle queues going aout of a destination.</returns>
	virtual TrafficModelObject * GetVehicleQueueOut(int Destination){return NULL;}
        
    /// <summary>Adds the vehicle given to the destination.</summary>
	///
	/// <param name="Vehicle">	pointer to the vehicle reaching the destination.</param>
	virtual void VehicleIn(VehicleClass* Vehicle);
        
    /// <summary>Vehicle queue out is full.</summary>
	///
	/// <param name="Destination">	Destination of the vehicle.</param>
	///
	/// <returns>Always return false, since it is the destination and reached the end. There is no Vehicle Out Queue.</returns>
	virtual bool VehicleQueueOutIsFull(int Destination){return false;}

	virtual void SetToStart(void);

};


}
