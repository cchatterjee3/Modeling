#pragma once
#include <stdlib.h>

namespace TrafficModelObjectsLibrary
{
#ifndef NULL
#define NULL 0
#endif
#ifndef nullptr
#define nullptr 0
#endif

/// <summary> Enumeration of the types of objects </summary>
enum ObjectType{
	UNDEFINED	 = 0,
	MODEL		 = 1,
	VEHICLE		 = 2,
	PARKINGLOT	 = 3,
	ROADSEGMENT	 = 4,
	INTERSECTION = 5,
	DESTINATION	 = 6,
	PHASE		 = 7
};

// Average Time Constants
/// <summary> The lower bound for the time taken for a car to start and move </summary>
const double TAKEOFF_TIME_LB = 1.425;
/// <summary> The upper bound for the time taken for a car to start and move </summary>
const double TAKEOFF_TIME_UB = 1.575;
/// <summary> The lower bound for the headway time </summary>
const double HEADWAY_TIME_LB = 0.7125;
/// <summary> The upper bound for the headway time </summary>
const double HEADWAY_TIME_UB = 0.7875;
/// <summary> The lower bound for time error </summary>
const double TIME_ERROR_LB = 0.95;
/// <summary> The upper bound for time error </summary>
const double TIME_ERROR_UB = 1.05;


/// <summary> Traffic model object </summary>
class TrafficModelObject
{
protected:
	/// <summary> The type of the object </summary>
	ObjectType mType;
public:
	/// <summary> Initializes a new instance of the TrafficModelObject class </summary>
	TrafficModelObject(void);
	/// <summary> Finalizes the instance of the TrafficModelObject class </summary>
	~TrafficModelObject(void);

	/// <summary> Return of the type of object </summary>
	///
	/// <returns> mType </returns>
	ObjectType Type();

};
}

