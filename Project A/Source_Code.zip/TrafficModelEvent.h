#pragma once
using namespace SimulatorObjectsLibrary;

namespace TrafficModelEventLibrary
{

	/// <summary> Enumeration of the types of possible events </summary>
	enum EventType{
		UNDEFINED = 0,
		PHASE_CHANGE = 1,
		SEEK_VEHICLE = 2,
		VEHICLE_EXITS_INTERSECTION = 3,
		VEHICLE_AT_FRONT = 4,
	};

/// <summary> Traffic Model Event Class </summary>
class TrafficModelEvent:
	public Event
{
protected:

		/// <summary> The type of the event </summary>
		EventType mType;
public:

	/// <summary> Initializes a new instance of the TrafficModelEvent class </summary>
	TrafficModelEvent(void);

	/// <summary> Finalizes an instance of the TrafficModelEvent class </summary>
	~TrafficModelEvent(void);

	/// <summary> Returns the type of event </summary>
	///
	/// <returns> mType </returns>
	EventType Type(void);

	/// <summary> Runs this object </summary>
	virtual void Run(void)=0;

	/// <summary> Sets the time of event </summary>
	///
	/// <param name="EventTime"> Time of the event </param>
	void SetEventTime(double EventTime);

	virtual void Release(void)=0;
};
}

