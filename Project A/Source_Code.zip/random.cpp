#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <iostream>
#include <string>
#include "random.h"

    
using namespace std;

namespace SimulatorObjectsLibrary
{

/// <summary>Gets the Lehmer Random number.</summary>
///
/// <returns>A random number between 0.0 and 1.0, 0.0 not included.</returns>

double clsRandomGenerator::Lehmer_Random(void)
{
  t = MULTIPLIER * (seed % QUOTIENT) - REMAINDER * (seed/QUOTIENT);
  if (t > 0) 
      seed= t;
  else
      seed = t + MODULUS;
  return ((double) seed/MODULUS);
}

/// <summary>Produces a Random Number uniformily distributed. Assumes uniform distribution of
/// 	values.</summary>
///
/// <param name="a">	Lower bound of the interval.</param>
/// <param name="b">	Upper bound of the interval.</param>
///
/// <returns>Random number of type int</returns>

int clsRandomGenerator::intUniformDist(int a, int b)
{
    int numbins=(b-a)+1;
    return int(numbins*Lehmer_Random());
    
}

/// <summary>Chi Test.</summary>
///
/// <param name="samples">	The number of samples.</param>
/// <param name="numbins">	The number of bins.</param>
///
/// <returns>.</returns>

double clsRandomGenerator::Chi_test(int samples, int numbins)
{
  int index;
    int * bins = (int*) malloc (numbins*sizeof(int));
    
    for (int i = 0; i<numbins; i++)
    {
        bins[i]=0;
    }
    
   
    //Want to generate an array of 1000 random values
    //So loop and call Lehmer_Random 1000 times.
    //Number of times to call Lehmer_Random
    //Number of bins
    int expected = samples/numbins;
    
    //Loop to call Lehmer_Random 1000 times and store in array
    for (int i = 0; i<samples; i++)
    {
        index=int(numbins*Lehmer_Random());
        bins[index]++;
    }
    double sumsquared = 0;
     for (int i = 0; i<numbins; i++)
    {
         //cout << bins[i] << '\n';
        sumsquared += (bins[i]-expected)*(bins[i]-expected)/expected;
    }
    
    //Loop through the array and place in bins and keep count
    //Bins need to be size of 1/k, so (0.0 - 0.01], (0.01 -0.02], etc
    //Have a count[index]
    return sumsquared;
    
    
    //Then calculated Chi-square
    // Sum 1-k of (count(index)-expected)/expected;
    // Compare to Chi-square value
    
}

/// <summary>Produces a Random Number uniformily distributed. Assumes uniform distribution of
/// 	values.</summary>
///
/// <param name="a">	Lower bound of the interval.</param>
/// <param name="b">	Upper bound of the interval.</param>
///
/// <returns>Random number of type double</returns>

double clsRandomGenerator::UniformDist(double a, double b)
{	 
  return (a + (b - a) * Lehmer_Random());
}

}

