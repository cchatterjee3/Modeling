#include "SimulatorClass.h"
#include "LinkedListPQClass.h"

namespace SimulatorObjectsLibrary
{

/// <summary>	Default constructor. </summary>
LinkedListPQClass::LinkedListPQClass(void)
{
	mNumberOfEventsInQueue = 0;
}

/// <summary>	Destructor. </summary>
LinkedListPQClass::~LinkedListPQClass(void)
{
}

/// <summary>	Adds an event. </summary>
///
/// <param name="ptrEvent">	[in,out] If non-null, the pointer event. </param>
///
/// <returns>	true if it succeeds, false if it fails. </returns>
bool LinkedListPQClass::AddEvent(Event* ptrEvent)
{
	bool placeFound = false;

	if (mNumberOfEventsInQueue == 0)
	{
		mEventsQueueList = ptrEvent;
		mNumberOfEventsInQueue++;
		return true;
	}

	Event* currentEvent = mEventsQueueList;

	if(ptrEvent->EventTime() < currentEvent->EventTime())
	{
		placeFound = true;
		ptrEvent->SetNext(currentEvent);
		mEventsQueueList = ptrEvent;
	}

	
	while(!placeFound)
	{
		if ( !currentEvent->Next())
		{
			placeFound = true;
			currentEvent->SetNext(ptrEvent);
		}
		else
		{
			if(ptrEvent->EventTime() > (currentEvent->Next())->EventTime())
			{
				currentEvent = currentEvent->Next();
			}
			else
			{
				placeFound = true;
				ptrEvent->SetNext(currentEvent->Next());
				currentEvent->SetNext(ptrEvent);
			}
		}
	}
if (placeFound) mNumberOfEventsInQueue++;

return placeFound;
}

/// <summary>	Pops the next. </summary>
///
/// <returns>	null if it fails, else. </returns>
Event * LinkedListPQClass::PopNext(void)
{
	if (IsEmpty())
	{
		return 0;
	}
	else
	{
        Event * ptrNext = mEventsQueueList;
		mEventsQueueList = mEventsQueueList->Next();
		ptrNext->SetNext(0);
		mNumberOfEventsInQueue--;
	    return ptrNext;
	}
	
}

/// <summary>	Pops the event described by ptrEvent. </summary>
///
/// <param name="ptrEvent">	[in,out] If non-null, the pointer event. </param>
///
/// <returns>	null if it fails, else. </returns>
Event * LinkedListPQClass::PopEvent(Event * ptrEvent)
{
	if (mNumberOfEventsInQueue > 0)
	{
		if(ptrEvent ==mEventsQueueList)
		{
			if(mEventsQueueList->Next())
			{
				mEventsQueueList = mEventsQueueList->Next();
			}
			else
			{
				mEventsQueueList = nullptr;
			}

			ptrEvent->SetNext(0);
			mNumberOfEventsInQueue--;
			return ptrEvent;
		}

		Event * ptrNext = mEventsQueueList;
		while(ptrNext)
	    {
			if (ptrNext->Next() == ptrEvent)
		    {
				ptrNext->SetNext(ptrEvent->Next());
			    ptrEvent->SetNext(0);
			    mNumberOfEventsInQueue--;
     	        return ptrEvent;
	        }
			ptrNext = ptrNext->Next();
		}
	}

	return 0;
}

/// <summary>	Query if this object is empty. </summary>
///
/// <returns>	true if empty, false if not. </returns>
bool LinkedListPQClass::IsEmpty()
{
	if (mNumberOfEventsInQueue == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void LinkedListPQClass::Reset(void)
{
	 mEventsQueueList = nullptr;
	 mNumberOfEventsInQueue = 0;
}
}
