#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"


namespace TrafficModelObjectsLibrary
{

/// <summary>	Initializes a new instance of the RoadSegmentClass class. </summary>
RoadSegmentClass::RoadSegmentClass(void){}

/// <summary>	Initializes a new instance of the RoadSegmentClass class. </summary>
///
/// <param name="Index">				Index of the pointer to the Road Segment into the Vehicle
/// 									Queue list of the Model. </param>
/// <param name="TrafficModel">			[in,out] Pointer to the model. </param>
/// <param name="Capacity">				The capacity of the road segment. </param>
/// <param name="AverageTravelTime">	The average time is takes a vehicle to cross the road
/// 									segment freely. </param>
/// <param name="Lanes">				The number of lanes for the road segment. </param>
/// <param name="StartTrafficNode"> 	The node at which the road segment starts. </param>
/// <param name="EndTrafficNode">   	The node at which the road segment ends. </param>
/// <param name="Phase">				The phase at which the vehicle queue in is going to be
/// 									served at the intersection ahead. </param>
/// <param name="Destinations">			The destinations. </param>
RoadSegmentClass::RoadSegmentClass(int Index, TrafficModelObject* TrafficModel, int Capacity, double AverageTravelTime, int Lanes, int StartTrafficNode, int EndTrafficNode, int Phase, int Destinations)
{
		mType = ROADSEGMENT;
        mCapacity = Capacity;
		mTrafficModel = TrafficModel;
        // We will compute the AverageTravelTime using excel.  
        // 
        mAverageTravelTime = AverageTravelTime; //J//Should this be the 45 mph?
        mExits = Lanes;//?
        mStartTrafficNodeIndex = StartTrafficNode; 
        mEndTrafficNodeIndex = EndTrafficNode;
        mPhaseIndex = Phase;
        mDestinationCount = 0;
		mDestinations = Destinations;
        mDestinationIDs = (int*) malloc (Destinations*sizeof(int));
        mIntersectionCrossingTime = (double*) malloc (Destinations*sizeof(double));
		ptrEndTrafficNode = ((TrafficModelClass*)TrafficModel)->GetTrafficNode(EndTrafficNode);
		ptrStartTrafficNode = ((TrafficModelClass*)TrafficModel)->GetTrafficNode(StartTrafficNode);
		ptrStartTrafficNode->AddVehicleQueueOut(this);
		mPhase = ptrEndTrafficNode->GetPhase(mPhaseIndex);
		mPhase->AddVehicleQueueIn(this);
        mIndexInList= Index;   
}



/// <summary>Finalizes an instance of the RoadSegmentClass class.</summary>
RoadSegmentClass::~RoadSegmentClass(void)
{
}

/// <summary>
/// Gets the vehicle out of the road segment and passes it to the intersection .
/// </summary>
///
/// <param name="Time">	The time that the vehicle will take to cross the intersection ahead . </param>
///
/// <returns>
/// null if it fails, returns a pointer to the vehicle issued by the road segment.
/// </returns>
VehicleClass *RoadSegmentClass::VehicleOut(double Time)
{
	if (mVehiclesReady > 0) 
	{
		VehicleClass* Vehicle = mVehicleReadyFront;
		mVehicleReadyFront = Vehicle->Next();
		Vehicle->setTravelTime(Time);
		Vehicle->setNext(nullptr);
		mVehiclesinQueue--;
		mVehiclesReady--;

			if (((TrafficModelClass*)mTrafficModel)->Trace()) 
	{
		ostream * outStr = ((TrafficModelClass*)mTrafficModel)->getOutputStream();
		*outStr << "V Out RS " << mIndexInList << ":\t" << Vehicle->ToString() << '\t' << Vehicle->getTravelTime() << '\n';
	}
		return Vehicle;
	}
	else
	{
		return nullptr;
	}
}

   
 void RoadSegmentClass::SetToStart(void)
{
    mVehiclesinQueue = 0;
	mVehicleReadyFront = nullptr;
	mVehicleReadyLast = nullptr;
	mVehiclesReady = 0;
}   

}
