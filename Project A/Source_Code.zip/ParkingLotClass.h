#pragma once

namespace TrafficModelObjectsLibrary
{

/// <summary>Parking lot class.</summary>
class ParkingLotClass :
	public VehicleQueueClass
{
public:

	/// <summary>Initializes a new instance of the ParkingLotClass class.</summary>
	ParkingLotClass(void);

	/// <summary>Initializes a new instance of the ParkingLotClass class.</summary>
	///
	/// <param name="Index">	   	Index of the pointer to the parking lot into the Vehicle Queue list of the Model </param>
	/// <param name="TrafficModel">	        Pointer to the model.</param>
	/// <param name="Capacity">	   	The capacity of the parking lot.</param>
	/// <param name="Exits">	   	The number of exit for the parking lot.</param>
	/// <param name="Intersection">	        Traffic node index corresponding the intersection outside the parking lot (End node).</param>
	/// <param name="Phase">	   	The phase that serves the traffic coming out of the parking lot.</param>
	/// <param name="Destinations">	        The number of destinations of the vehicles in the parking lot.</param>
	ParkingLotClass(int Index, TrafficModelObject* TrafficModel, int Capacity, int Exits, int Intersection, int Phase, int Destinations);
	
	/// <summary>Finalizes an instance of the ParkingLotClass class.</summary>
	~ParkingLotClass(void);

	/// <summary> Gets the vehicle out of the parking lot and passes it to the intersection .</summary>
	///
	/// <param name="Time">	The time that the vehicle will take to cross the intersection ahead .</param>
	///
	/// <returns>null if it fails, returns a pointer to the vehicle issued by the parking lot.</returns>
	virtual VehicleClass *VehicleOut(double Time);

	virtual void SetToStart(void);
};
}
