#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"


namespace TrafficModelObjectsLibrary
{

/// <summary>	Initializes a new instance of the Destination Class. </summary>
///
/// <param name="Index">			  	Index of the destination in the traffic node list. </param>
/// <param name="TrafficModel">		  	[in,out] pointer to the Model. </param>
/// <param name="AverageCrossingTime">	Time of the average crossing. </param>
DestinationClass::DestinationClass(int Index, TrafficModelObject * TrafficModel, double AverageCrossingTime)
{
    mType = DESTINATION;
    mAverageCrossingTime = AverageCrossingTime;
    mCummulativeTime = 0;
    mVehiclesServed = 0;
	mIndexInList = Index;
	mPhasesMax = 1;
    mPhasesList = (PhaseClass**) malloc(sizeof(PhaseClass*)*mPhasesMax);
	mPhasesList[0] = new PhaseClass(0,1,AverageCrossingTime);
	mPhasesCount = 1;

	mVehiclesIn = 0;
	mVehicleQueuesOut = 0;
	mVehicleQueuesOutCount = 0;
	mVehicleQueuesOutList = nullptr;
	mNextPhaseChangeScheduledEvent = nullptr;
	mTrafficModel = TrafficModel;
}


/// <summary>	Gets the average time. </summary>
///
/// <returns>	The average time. </returns>
double DestinationClass::GetAverageTime(void)
{
	if (mVehiclesServed > 0)
	{
	return mCummulativeTime / ((double)mVehiclesServed);
	}
	else
	{
		return 0;
	}
}

/// <summary>	Adds the vehicle given to the destination. </summary>
///
/// <param name="Vehicle">	[in,out] pointer to the vehicle reaching the destination. </param>
void DestinationClass::VehicleIn(VehicleClass* Vehicle)
{
	if (((TrafficModelClass*)mTrafficModel)->Trace()) 
	{
		ostream * outStr = ((TrafficModelClass*)mTrafficModel)->getOutputStream();
		*outStr  << "V Out D " << mIndexInList << ":\t" << Vehicle->ToString() << '\t' << Vehicle->getTravelTime() << '\n';
	}
	  mVehiclesServed++;
	  mCummulativeTime += Vehicle->getTravelTime() + mAverageCrossingTime;
	  Vehicle->Release();
	  delete Vehicle;
}

void DestinationClass::SetToStart(void)
{
	mVehiclesServed = 0;
	mCummulativeTime = 0;
    mVehiclesIn = 0;
	mNextPhaseChangeScheduledEvent = nullptr;
	mIdle = true;
	mActivePhaseIndex = 0;

}

}
