#pragma once
using namespace std;

namespace TrafficModelObjectsLibrary
{

/// <summary>VehicleClass object</summary>
class VehicleClass:
	public TrafficModelObject
{
protected:
	/// <summary> A pointer to the next Vehicle object. </summary>
	VehicleClass* mNext;
	/// <summary>	Index of the destination for the vehicle. </summary>
	int mDestination;
    /// <summary>	A pointer to the the traffic model. </summary>
    TrafficModelObject* mTrafficModel;
	/// <summary>	Starting time for a vehicle </summary>
	double mStartTime;
	/// <summary> Time the vehicle has taken to travel </summary>
	double mTravelTime;
	/// <summary>Index of the ParkingLot that issued the Vehicle</summary>
	int mIssuedBy;
	/// <summary>ID of the Vehicle</summary>
	int mID;

public:

	/// <summary>Default constructor</summary>
	VehicleClass(void);

	/// <summary>VehicleClass constructor with parameters</summary>
	///
	/// <param name="TrafficModel">	[in,out] If non-null, pointer to the traffic model.</param>
	/// <param name="Destination"> 	Integer ID for the Destination for the vehicle.</param>
	/// <param name="IssuedBy">	   	ID/Index of the parking lot that issued the VehicleClass object.</param>
	/// <param name="ID">		   	The identifier.</param>
	VehicleClass(TrafficModelObject* TrafficModel, int Destination, int IssuedBy, int ID);

	/// <summary>VehicleClass Destructor</summary>

	~VehicleClass(void);

	/// <summary>Gets the next VehicleClass object.</summary>
	///
	/// <returns>If there is no next VehicleClass object returns null</returns>

	VehicleClass* Next();

	/// <summary>Gets the destination of the VehicleClass object</summary>
	///
	/// <returns>Integer: Destination ID</returns>
	int getDestination();

	/// <summary>Sets a pointer to the next VehicleClass object</summary>
	///
	/// <param name="mNext">	[in,out] If non-null, a pointer to the next VehicleClass object</param>

	void setNext(VehicleClass* mNext);

	/// <summary>Gets the VehicleClass object's start time.</summary>
	///
	/// <returns> Double:Starttime</returns>

	double getStartTime(void);

	/// <summary>Sets a VehicleClass object's start time.</summary>
	///
	/// <param name="dblStartTime">	start time (double) </param>

	void setStartTime(double dblStartTime);

	/// <summary>Gets the travel time of the VehicleClass object.</summary>
	///
	/// <returns>The travel time as a double</returns>

	double getTravelTime(void);

	/// <summary>Sets a travel time for the VehicleClass object.</summary>
	///
	/// <param name="dblTravelTime"> Travel time as a double</param>

	void setTravelTime(double dblTravelTime);

	/// <summary>Convert this object into a string representation.</summary>
	///
	/// <returns>Returns a string representation of the VehicleClass object describing attributes like start time, and issue id</returns>

	char* ToString(void);

	void Release(void);
};

}
