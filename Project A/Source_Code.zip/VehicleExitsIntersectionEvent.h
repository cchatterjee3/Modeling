#pragma once
using namespace SimulatorObjectsLibrary;
using namespace TrafficModelObjectsLibrary;

namespace TrafficModelEventLibrary
{


/// <summary>The object vehicle exits an intersection event</summary>
class VehicleExitsIntersectionEvent:
		public TrafficModelEvent
{
protected:
	/// <summary>The number of vehicles.</summary>
	VehicleClass * mVehicle;
	/// <summary>The ID of the intersection.</summary>
	TrafficNodeClass * mIntersection;
	/// <summary>The number of vehicle queues feeding into the intersection</summary>
	VehicleQueueClass * mVehicleQueueIn;
	/// <summary>The number of vehicle queue feeding out of the intersection</summary>
	VehicleQueueClass * mVehicleQueueOut;

public:
	/// <summary>Constructor for a new instance of the VehicleExitsIntersectionEvent class.</summary>
	VehicleExitsIntersectionEvent(void);

	/// <summary>Initializes a new instance of the VehicleExitsIntersectionEvent class.</summary>
	///
	/// <param name="Vehicle">		  	[in,out] Pointer to the vehicle.</param>
	/// <param name="Intersection">   	[in,out] Pointer to the intersection</param>
	/// <param name="VehicleQueueOut">	[in,out] Pointer to the outgoing vehicle queue</param>
	/// <param name="EventTime">	  	Time of the event.</param>

	VehicleExitsIntersectionEvent(VehicleClass* Vehicle, TrafficNodeClass *Intersection,  VehicleQueueClass* VehicleQueueOut, double EventTime);
	/// <summary>Destructor of a VehicleExitIntersections Event</summary>
	~VehicleExitsIntersectionEvent(void);

	/// <summary>Process and execute an Event object</summary>
	virtual void Run(void);

	virtual void Release(void);

};

}
