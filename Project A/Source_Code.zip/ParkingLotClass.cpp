#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"


namespace TrafficModelObjectsLibrary
{

/// <summary>	Initializes a new instance of the ParkingLotClass class. </summary>
ParkingLotClass::ParkingLotClass(void)
{
}

/// <summary>	Initializes a new instance of the ParkingLotClass class. </summary>
///
/// <param name="Index">			  	Index of the pointer to the parking lot into the Vehicle
/// 									Queue list of the Model. </param>
/// <param name="TrafficModel">		  	[in,out] Pointer to the model. </param>
/// <param name="Capacity">			  	The capacity of the parking lot. </param>
/// <param name="Exits">			  	The number of exit for the parking lot. </param>
/// <param name="EndTrafficNodeIndex">	The end traffic node index. </param>
/// <param name="Phase">			  	The phase that serves the traffic coming out of the
/// 									parking lot. </param>
/// <param name="Destinations">		  	The number of destinations of the vehicles in the parking
/// 									lot. </param>
ParkingLotClass::ParkingLotClass(int Index, TrafficModelObject* TrafficModel, int Capacity, int Exits, int EndTrafficNodeIndex, int Phase, int Destinations)
{
	mType = PARKINGLOT;
	mTrafficModel = TrafficModel;
	mCapacity = Capacity;
	mExits = Exits;
	mVehiclesinQueue = Capacity;
    mDestinationCount = 0;
	mDestinations = Destinations;
    mDestinationIDs = (int*) malloc (Destinations*sizeof(int));
    mIntersectionCrossingTime = (double*) malloc (Destinations*sizeof(double));
    mEndTrafficNodeIndex = EndTrafficNodeIndex;
    ptrEndTrafficNode = ((TrafficModelClass*)TrafficModel)->GetTrafficNode(EndTrafficNodeIndex);
    mPhaseIndex = Phase;
	mPhase = ((IntersectionClass*)ptrEndTrafficNode)->GetPhase(Phase);
	mPhase->AddVehicleQueueIn(this);
	mIndexInList= Index;
      
}

/// <summary>	Destructor. </summary>
ParkingLotClass::~ParkingLotClass(void)
{
}

/// <summary>	Vehicle out. </summary>
///
/// <param name="Time">	The time. </param>
///
/// <returns>	null if it fails, else. </returns>
VehicleClass* ParkingLotClass::VehicleOut(double Time)
{

	VehicleClass *Vehicle = mVehicleReadyFront;
	Vehicle->setTravelTime(Time);
	mVehiclesinQueue--;

	int Destination;

	if (((TrafficModelClass*)mTrafficModel)->Check())
	{
	    Destination = mCapacity - mVehiclesinQueue;
	}
	else
	{
		clsRandomGenerator * RandomGenerator =  ((TrafficModelClass*)mTrafficModel)->RandomGenerator();
	    Destination = RandomGenerator->intUniformDist(0,mDestinationCount - 1);
	}

	if (mVehiclesinQueue > 0)
	{
		mVehicleReadyFront = new VehicleClass(this->mTrafficModel, mDestinationIDs[Destination], mIndexInList, mCapacity - mVehiclesinQueue);
	}
	else
	{
		mVehicleReadyFront = nullptr;
        mVehiclesReady--;
	}
	
	if (((TrafficModelClass*)mTrafficModel)->Trace()) 
	{
		ostream * outStr = ((TrafficModelClass*)mTrafficModel)->getOutputStream();
		*outStr << "V Out PL " << mIndexInList << ":\t" << Vehicle->ToString() << '\t' << Vehicle->getTravelTime() << '\n';
	}
	return Vehicle;
}

void ParkingLotClass::SetToStart(void)
{
	int Destination;
	if (((TrafficModelClass*)mTrafficModel)->Check())
	{ 
		mCapacity = mDestinations;
		Destination = 0;
	}
	else
	{
		clsRandomGenerator * RandomGenerator =  ((TrafficModelClass*)mTrafficModel)->RandomGenerator();
	    Destination = RandomGenerator->intUniformDist(0,mDestinationCount - 1);
	}

	mVehiclesinQueue = mCapacity;
	if (mCapacity > 0)
	{   
		mVehiclesReady = 1;
		mVehicleReadyFront = new VehicleClass(this->mTrafficModel, mDestinationIDs[Destination], mIndexInList, 0);
	}

}
}
