#include "Event.h"

namespace SimulatorObjectsLibrary
{

/// <summary>	Default constructor. </summary>
Event::Event(void)
{
	mNext = NULL;
}

/// <summary>	Destructor. </summary>
Event::~Event(void){}

/// <summary>	Gets the event time. </summary>
///
/// <returns> The event time. </returns>
double Event::EventTime(void)
{
	return mEventTime;
}

/// <summary>	Gets the pointer to the next even in the linked list. </summary>
///
/// <returns>	null if it there is not a next event, else a pointer to the linked list. </returns>
Event* Event::Next(void)
{
	return mNext;
}

/// <summary>	Set the pointer to the next event. </summary>
///
/// <param name="nextEvent">	[in,out] The next event. </param>
void Event::SetNext(Event* nextEvent)
{
	mNext = nextEvent;
}

/// <summary>	Sets event time. </summary>
///
/// <param name="EventTime">	Time of the event. </param>
void Event::SetEventTime(double EventTime)
{
	mEventTime = EventTime;
}
}
