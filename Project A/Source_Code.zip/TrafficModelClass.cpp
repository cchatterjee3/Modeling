#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"

// namespace: TrafficModelObjectsLibrary
//
// summary:	Contains the objects required to create a Traffic Model.
namespace TrafficModelObjectsLibrary
{

/// <summary>Initializes a new instance of the TrafficModelClass.</summary>
///
/// <param name="Destinations"> 	Number of Destinations.</param>
/// <param name="Intersections">	Number of Intersections.</param>
/// <param name="ParkingLots">  	Number of Parking Lots.</param>
/// <param name="RoadSegments"> 	Number of Road Segments.</param>
TrafficModelClass::TrafficModelClass(int Destinations, int Intersections, int ParkingLots, int RoadSegments)
{
	// Initializes Members 
	mType = MODEL;
	mTrace = false;
	mCheck = false;
	mNodesCount = 0;
	mVehicleQueuesCount = 0;
	mDestinations = Destinations;
	mIntersections = Intersections;
	mParkingLots = ParkingLots;
	mRoadSegments = RoadSegments;
	mSimulator = nullptr;
	mRandomGenerator = nullptr;
	mOutputStream = &cout;

	// Alocate memory for pointers lists
	mNodesList = (TrafficNodeClass**) malloc((Destinations + Intersections) * sizeof(TrafficNodeClass*));
	mVehicleQueuesList = (VehicleQueueClass**) malloc((ParkingLots + RoadSegments) * sizeof(VehicleQueueClass*));
}

/// <summary>Creates a new Destination and adds its pointer to the pointers list of Traffic Nodes
/// 	of the Model.</summary>
///
/// <param name="AverageCrossingTime">	The average time a vehicle spend thru the exit road. It
/// 									may be zero if there is not exit road.</param>
///
/// <returns>null if it fails, else a pointer to the new Destination.</returns>

DestinationClass * TrafficModelClass::AddDestination(double AverageCrossingTime)
{
	// Creates new Destination
	DestinationClass* ptrDestination =new DestinationClass(mNodesCount, this, AverageCrossingTime);
    
	// Adds it to the Traffic Nodes List.
	mNodesList[mNodesCount] = ptrDestination;
	
	// Increase the Traffic Nodes count by 1.
	mNodesCount++;

	// return the pointer to the new Destination
	return ptrDestination;
}

/// <summary>Creates a new Intersection and adds its pointer to the pointers list of Traffic Nodes
/// 	of the Model.</summary>
///
/// <param name="Phases">   	The number of Phases in the Intersection.</param>
/// <param name="QueuesOut">	The number of Vehicle Queues going out of the Intersection.</param>
///
/// <returns>null if it fails, else a pointer to the new Intersection.</returns>

IntersectionClass * TrafficModelClass::AddIntersection(int Phases, int QueuesOut){
    
	// Creates new Intersection
	IntersectionClass * ptrIntersection = new IntersectionClass(mNodesCount, this, Phases, QueuesOut);
        
    // Adds it to the Traffic Nodes List.
    mNodesList[mNodesCount] = ptrIntersection;
        
    // Increase the Traffic Nodes count by 1.
    mNodesCount++;
        
    // return the pointer to the new Destination
	return ptrIntersection;
}

/// <summary>Creates a new Parking Lot and adds its pointer to pointers list of Vehicle Queues of
/// 	the Model.</summary>
///
/// <param name="Capacity">		 	The number of vehicles than can be parked in the Parking Lot.</param>
/// <param name="Exits">		 	The number of exits.</param>
/// <param name="EndTrafficNode">	The index in the Traffic Nodes pointers list corresponding to
/// 								the Traffic Node outside the Parking Lot.</param>
/// <param name="Phase">		 	The index in the Phases pointers list corresponding to the
/// 								Phase which evacuates Vehicles from the Parking Lot.</param>
/// <param name="Destinations">  	The number of Destinations available to the Vehicles in the
/// 								Parking Lot.</param>
///
/// <returns>null if it fails, else a pointer to the new Parking Lot.</returns>

ParkingLotClass * TrafficModelClass::AddParkingLot(int Capacity, int Exits, int EndTrafficNode, int Phase, int Destinations)
{
	// Creates new Parking Lot
    ParkingLotClass* currentParkingLot = new ParkingLotClass(mVehicleQueuesCount, this, Capacity, Exits, EndTrafficNode, Phase, Destinations);
    
	// Adds it to the Vehicle Queues List.
	mVehicleQueuesList[mVehicleQueuesCount] = currentParkingLot;
    
	// Increase the Vehicle Queues count by 1.
	mVehicleQueuesCount++;

	// returns the pointer to the new Parking Lot.
    return currentParkingLot;
}

/// <summary>Creates a new Road Segment and adds its pointer to pointers list of Vehicle Queues of
/// 	the Model.</summary>
///
/// <param name="Capacity">				The number of vehicles than can ocupy the Road Segment.</param>
/// <param name="AverageTravelTime">	Time to travel de Road Segment at average speed.</param>
/// <param name="Lanes">				The number of lanes.</param>
/// <param name="StartTrafficNode"> 	The index in the Traffic Nodes pointers list
/// 									corresponding to the Traffic Node where the Road Segment
/// 									Starts.</param>
/// <param name="EndTrafficNode">   	The index in the Traffic Nodes pointers list
/// 									corresponding to the Traffic Node where the Road Segment Ends.</param>
/// <param name="Phase">				The index in the Phases pointers list corresponding to
/// 									the Phase which evacuates Vehicles from the Road Segment.</param>
/// <param name="Destinations">			The number of Destinations served by the Road Segment.</param>
///
/// <returns>null if it fails, else a pointer to the new Road Segment.</returns>
RoadSegmentClass * TrafficModelClass::AddRoadSegment(int Capacity, double AverageTravelTime, int Lanes, int StartTrafficNode, int EndTrafficNode, int Phase, int Destinations)
{
	// Creates new Road Segment
    RoadSegmentClass * currentRoadSegment = new RoadSegmentClass(mVehicleQueuesCount, this, Capacity, AverageTravelTime, Lanes, StartTrafficNode, EndTrafficNode, Phase, Destinations);
    
	// Adds it to the Vehicle Queues List.
	mVehicleQueuesList[mVehicleQueuesCount] = currentRoadSegment;

	// Increase the Vehicle Queues count by 1.
    mVehicleQueuesCount++;
 
	// returns the pointer to the new Road Segment.
	return currentRoadSegment;
}

void TrafficModelClass::SetToStart(void)
{
	for (int i = 0; i < mNodesCount; i++)
	{
		((TrafficNodeClass*)mNodesList[i])->SetToStart();
	}

	for (int i = 0; i < mVehicleQueuesCount; i++)
	{
		((VehicleQueueClass*)mVehicleQueuesList[i])->SetToStart();
	}

	mSimulator->Reset();
}

int TrafficModelClass::TotalVehiclesServed(void)
{
	mTotalVehiclesServed = 0;
	for (int i = 0; i < mDestinations; i++)
	{
		if(mNodesList[i]->Type() == DESTINATION)
		{
			mTotalVehiclesServed += ((DestinationClass*)mNodesList[i])->GetVehiclesServed();
		}
	}

	return mTotalVehiclesServed;
}

double TrafficModelClass::TotalCummulativeTime(void)
{
	mTotalCummulativeTime = 0.0;
	for (int i = 0; i < mDestinations; i++)
	{
		if(mNodesList[i]->Type() == DESTINATION)
		{
			mTotalCummulativeTime += ((DestinationClass*)mNodesList[i])->GetCummulativeTime();
		}
	}

	return mTotalCummulativeTime;
}

double TrafficModelClass::AverageDelayTime(void)
{
	TotalVehiclesServed();
	TotalCummulativeTime();

	if (mTotalVehiclesServed > 0.0)
	{
		return mTotalCummulativeTime/((double)mTotalVehiclesServed) ;
	}
	else
	{
		return 0.0;
	}
}

}
