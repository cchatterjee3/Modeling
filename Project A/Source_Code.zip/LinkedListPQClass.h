#pragma once


namespace SimulatorObjectsLibrary
{

/// <summary>Linked list pq class.</summary>
class LinkedListPQClass:
	public SimulatorClass
{
protected:
    /// <summary>Pointer to an array of Event objects</summary>
    Event* mEventsQueueList;
	/// <summary>Number of events in the EventQueueList</summary>
	unsigned int mNumberOfEventsInQueue;

public:
	/// <summary>Initializes a new instance of the LinkedListPQClass class.</summary>
	LinkedListPQClass(void);
	
	/// <summary>Finalizes an instance of the LinkedListPQClass class.</summary>
	~LinkedListPQClass(void);

	/// <summary>Adds an event.</summary>
	///
	/// <param name="Event">	[in,out] If non-null, the event.</param>
	///
	/// <returns>true if it succeeds, false if it fails.</returns>
	virtual bool AddEvent(Event *Event);

	/// <summary>Pops the event described by Event.</summary>
	///
	/// <param name="Event">	[in,out] If non-null, the event.</param>
	///
	/// <returns>null if it fails, else.</returns>
	virtual Event* PopEvent(Event *Event);

	/// <summary>Pops the next.</summary>
	///
	/// <returns>null if it fails, else.</returns>
	virtual Event* PopNext(void);

	/// <summary>Query if this object is empty.</summary>
	///
	/// <returns>true if empty, false if not.</returns>
	virtual bool IsEmpty(void);

	virtual void Reset(void);

};

}

