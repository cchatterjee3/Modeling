#pragma once
using namespace SimulatorObjectsLibrary;

namespace TrafficModelObjectsLibrary
{

/// <summary> Traffic Model Class </summary>
class TrafficModelClass:
	public TrafficModelObject
{ 
protected:
	/// <summary> Number of Destinations in the Model </summary>
	int mDestinations;
	
	/// <summary> Number of Intersections in the Model </summary>
	int mIntersections;
	
	/// <summary> Number of Parking Lots in the Model </summary>
	int mParkingLots;
	
	/// <summary> Number of Road Segments in the Model </summary>
	int mRoadSegments;
    
	/// <summary> Counter for the Traffic Nodes in the Model. When the Model is fully set up, the Traffic Nodes count should be equal to the sum of Destinations plus Intersections</summary>
    int mNodesCount;
	
	/// <summary>Counter for the Vehicle Queues. When the Model is fully set up, the Vehicle Queues count should be equal to the sum of Parking Lots and Road Segments</summary>
	int mVehicleQueuesCount;
	
	/// <summary> List of pointers to the Traffic Nodes </summary>
	TrafficNodeClass ** mNodesList;
	
	/// <summary> List of pointers to the Vehicle Queues </summary>
	VehicleQueueClass ** mVehicleQueuesList;
    
	/// <summary> Pointer to a Simulator </summary>
    SimulatorClass * mSimulator;

	/// <summary> Pointer to the Random Number Generator </summary>
	clsRandomGenerator * mRandomGenerator;

	/// <summary> Boolean value to indicate weather or not to produce intermediate output </summary>
	bool mTrace;

	/// <summary> Boolean value to indicate the Traffic Model is in Check mode </summary>
	bool mCheck;

	/// <summary> Pointer to the output stream to be used </summary>
	ostream *mOutputStream;

	int mTotalVehiclesServed;
	double mTotalCummulativeTime;

public:
	/// <summary> Initializes a new instance of the TrafficModelClass </summary>
	TrafficModelClass(void){};

	/// <summary> Finalizes the instance of the TrafficModelClass </summary>
	~TrafficModelClass(void){};

	/// <summary> Initializes a new instance of the TrafficModelClass with the given number of elements in the traffic </summary>
	///
	/// <param name="Destinations"> 	Number of Destinations </param>
	/// <param name="Intersections">	Number of Intersections </param>
	/// <param name="ParkingLots">  	Number of Parking Lots </param>
	/// <param name="RoadSegments"> 	Number of Road Segments </param>
	TrafficModelClass(int Destinations, int Intersections, int ParkingLots, int RoadSegments);

	/// <summary>Creates a new Destination and adds its pointer to the pointers list of Traffic Nodes
	/// 	of the Model</summary>
	///
	/// <param name="AverageCrossingTime">	The average time a vehicle spend thru the exit road. It
	/// 									may be zero if there is not exit road</param>
	///
	/// <returns>null if it fails, else a pointer to the new Destination</returns>
	DestinationClass * AddDestination(double AverageCrossingTime);
	
	/// <summary>Creates a new Intersection and adds its pointer to the pointers list of Traffic Nodes
	/// 	of the Model</summary>
	///
	/// <param name="Phases">   	The number of Phases in the Intersection</param>
	/// <param name="QueuesOut">	The number of Vehicle Queues going out of the Intersection</param>
	///
	/// <returns>null if it fails, else a pointer to the new Intersection</returns>
	IntersectionClass * AddIntersection(int Phases, int QueuesOut);
	
	/// <summary>Creates a new Parking Lot and adds its pointer to pointers list of Vehicle Queues of
	/// 	the Model</summary>
	///
	/// <param name="Capacity">		 	The number of vehicles than can be parked in the Parking Lot</param>
	/// <param name="Exits">		 	The number of exits</param>
	/// <param name="EndTrafficNode">	The index in the Traffic Nodes pointers list corresponding to
	/// 								the Traffic Node outside the Parking Lot</param>
	/// <param name="Phase">		 	The index in the Phases pointers list corresponding to the
	/// 								Phase which evacuates Vehicles from the Parking Lot</param>
	/// <param name="Destinations">  	The number of Destinations available to the Vehicles in the
	/// 								Parking Lot</param>
	///
	/// <returns>null if it fails, else a pointer to the new Parking Lot</returns>
	ParkingLotClass * AddParkingLot(int Capacity, int Exits, int EndTraficNode, int Phase, int Destinations);
	
	/// <summary>Creates a new Road Segment and adds its pointer to pointers list of Vehicle Queues of
	/// 	the Model</summary>
	///
	/// <param name="Capacity">				The number of vehicles than can ocupy the Road Segment</param>
	/// <param name="AverageTravelTime">	Time to travel de Road Segment at average speed</param>
	/// <param name="Lanes">				The number of lanes</param>
	/// <param name="StartTrafficNode"> 	The index in the Traffic Nodes pointers list
	/// 									corresponding to the Traffic Node where the Road Segment
	/// 									Starts</param>
	/// <param name="EndTrafficNode">   	The index in the Traffic Nodes pointers list
	/// 									corresponding to the Traffic Node where the Road Segment Ends</param>
	/// <param name="Phase">				The index in the Phases pointers list corresponding to
	/// 									the Phase which evacuates Vehicles from the Road Segment</param>
	/// <param name="Destinations">			The number of Destinations served by the Road Segment</param>
	///
	/// <returns>null if it fails, else a pointer to the new Road Segment</returns>
	RoadSegmentClass * AddRoadSegment(int Capacity, double AverageTravelTime, int Lanes, int StartTrafficNode, int EndTrafficNode, int Phase, int Destinations);

	/// <summary>Gets a pointer to a Traffic Node</summary>
	///
	/// <param name="Index">	Zero-based index of the pointer in the list of Traffic Nodes</param>
	///
	/// <returns>Pointer to the requested traffic node, NULL if fail</returns>
	TrafficNodeClass * GetTrafficNode(int Index){return mNodesList[Index];}

	/// <summary>Gets the pointer to a Vehicle Queue</summary>
	///
	/// <param name="Index">	Zero-based index of the pointer in the list of Vehicle Queues</param>
	///
	/// <returns>null if it fails, else the pointer to a Vehicle Queue</returns>
	VehicleQueueClass * GetVehicleQueue(int Index){return mVehicleQueuesList[Index];}

	/// <summary>Gets the Destinations count</summary>
	///
	/// <returns>The number of Destinations in the Model</returns>
	int DestinationsCount(){return mDestinations;}

	/// <summary>Gets the Intersections count</summary>
	///
	/// <returns>The number of Intersections in the Model</returns>
	int IntersectionsCount(){return mIntersections;}

	/// <summary>Gets the Parking Lots count</summary>
	///
	/// <returns>The number of Parking Lots in the Model</returns>
	int ParkingLotsCount(){return mParkingLots;}

	/// <summary>Gets the Road Segments count</summary>
	///
	/// <returns>The number of Road Segments in the Model</returns>
	int RoadSegmentsCount(){return mRoadSegments;}

	/// <summary>Gets the Traffic Nodes count</summary>
	///
	/// <returns>The number of Traffic Nodes in the Model. For consistency, this value should be equal to the sum of Destinations and Intersections</returns>
	int NodesCount(){return mNodesCount;}

	/// <summary>Gets the Vehicle Queues count</summary>
	///
	/// <returns>The number of Vehicle Queues in the Model. For consistency, this value should be equal to the sum of Parking Lots and Road Segments</returns>
	int VehicleQueuesCount(){return mVehicleQueuesCount;}

	/// <summary>Gets the Trace state. If Trace is true, intermediate output is produced during the simulation</summary>
	///
	/// <returns>True/false</returns>
	bool Trace(void){return mTrace;}

	/// <summary>Sets a the Trace state</summary>
	///
	/// <param name="bTrace">	True to produce intermediate output, false to omit it</param>
	void setTrace(bool bTrace){mTrace = bTrace;}

	/// <summary>Sets a Check mode</summary>
	///
	/// <param name="bCheck">	True to set the Model in Check mode</param>
	void setCheck(bool bCheck){mCheck = bCheck;}

	/// <summary>Gets the Check state. If Check is true, The Parking Lots capacity is set to the
	/// 	number of destinations, and a vehicle per destination will be issued form each Parking
	/// 	Lot</summary>
	///
	/// <returns>true if it succeeds, false if it fails</returns>

	bool Check(void){return mCheck;}

	/// <summary>Sets an output stream</summary>
	///
	/// <param name="OutputStream">	[in,out] If non-null, stream to write data to</param>
	void setOutputStream(ostream *OutputStream){mOutputStream = OutputStream;}

	/// <summary>Gets the output stream</summary>
	///
	/// <returns>null if it fails, else the output stream</returns>
	ostream* getOutputStream(void){return mOutputStream;}

	/// <summary>Sets a Simulator</summary>
	///
	/// <param name="Simulator">	[in,out] If non-null, the simulator</param>
	void setSimulator(SimulatorClass* Simulator){mSimulator = Simulator;}

	/// <summary>Gets the Simulator</summary>
	///
	/// <returns>null if it fails, else the pointer to the Simulator</returns>
	SimulatorClass * Simulator(void){return mSimulator;};

	/// <summary>Sets a Random Number Generator</summary>
	///
	/// <param name="RandomGenerator">	[in,out] If non-null, the random number generator</param>
	void setRandomGenerator(clsRandomGenerator * RandomGenerator){mRandomGenerator = RandomGenerator;}

	/// <summary>Gets the random generator</summary>
	///
	/// <returns>null if it fails, else the pointer to the Random umber Generator</returns>
	clsRandomGenerator * RandomGenerator(void){return mRandomGenerator;}

	void SetToStart(void);

	int TotalVehiclesServed(void);
	double TotalCummulativeTime(void);
	double AverageDelayTime(void);
};

}

