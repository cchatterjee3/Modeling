#pragma once
namespace TrafficModelObjectsLibrary
{
/// <summary>Intersection class.</summary>
class IntersectionClass:
	public TrafficNodeClass
{
public:
	/// <summary>Initializes a new instance of the IntersectionClass class.</summary>
	IntersectionClass(void);

	/// <summary>Initializes a new instance of the IntersectionClass class.</summary>
	///
	/// <param name="Index">	   	Index of the intersection in the traffic node list.</param>
	/// <param name="TrafficModel">	 pointer to the model.</param>
	/// <param name="PhasesMax">   	The maximum number of phases for the current intersection.</param>
	/// <param name="QueuesOut">   	The number of vehicle Queues going out of the intersection.</param>

	IntersectionClass(int Index, TrafficModelObject * TrafficModel, int PhasesMax, int QueuesOut);
	
	/// <summary>Finalizes an instance of the IntersectionClass class.</summary>
	~IntersectionClass(void);

	/// <summary> Creates a phase and returns the pointer to it.</summary>
	///
	/// <param name="QueuesIn">			 	The number of queues delivering cars to the intersection at the current phase.</param>
	/// <param name="AverageServiceTime">	The interval of time at which the phase is going to run .</param>
	///
	/// <returns>null if it fails, returns pointers of current created phase.</returns>

	PhaseClass* AddPhase(int QueuesIn, double AverageServiceTime);

	/// <summary>Gets the pointer at the given index in the pointer phases list of the intersection.</summary>
	///
	/// <param name="Index">	Index of the pointer to the required phase.</param>
	///
	/// <returns>null if it fails, else returns the pointer to the Phase.</returns>

	PhaseClass* GetPhase(int Index);
    

	/// <summary>Gets the vehicle queue going out of the intersection which serves the destination given.</summary>
	///
	/// <param name="Destination">	Destination of the vehicle using the intersection.</param>
	///
	/// <returns>null if it fails, else the pointer to the vehicle queue serving the given destination.</returns>

	virtual TrafficModelObject * GetVehicleQueueOut(int Destination);


        
    /// <summary>Adds the vehicle given to the intersection.</summary>
	///
	/// <param name="Vehicle">	pointer to the vehicle reaching the intersection.</param>
	virtual void VehicleIn(VehicleClass* Vehicle);

	/// <summary> Checks if the vehicle queue  going out of the intersection and serving the given destination is full.</summary>
	///
	/// <param name="Destination">	Destination of the vehicle.</param>
	///
	/// <returns>The full status of the vehicle queue serving the destination out of the current intersection.</returns>
	virtual bool VehicleQueueOutIsFull(int Destination);

	virtual void SetToStart(void);

};
}

