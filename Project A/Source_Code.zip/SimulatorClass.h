#pragma once
#include "random.h"
#include "Event.h"

namespace SimulatorObjectsLibrary
{

/// <summary>SimulatorClass Object</summary>
class SimulatorClass
{
public:
	/// <summary>Initializes a new instance of the SimulatorClass class.</summary>
	SimulatorClass(void){};
	/// <summary>Finalizes an instance of the SimulatorClass class.</summary>
	~SimulatorClass(void){};

    /// <summary>Adds an event to the Simulator</summary>
    ///
    /// <param name="Event">	[in,out] If non-null, the event.</param>
    ///
    /// <returns>true if it succeeds, false if it fails.</returns>

    virtual bool AddEvent(Event *Event)=0;

	/// <summary>Pops the event addressed by Event</summary>
	///
	/// <param name="Event">	[in,out] If non-null, the event.</param>
	///
	/// <returns>false if it fails, else returns true</returns>

	virtual Event* PopEvent(Event *Event)=0;

	/// <summary>Pops the next Event.</summary>
	///
	/// <returns>Returns pointer to the next event </returns>

	virtual Event* PopNext(void)=0;

	/// <summary>Query if this object is empty.</summary>
	///
	/// <returns>true if empty, false if not.</returns>

	virtual bool IsEmpty(void)=0;

	virtual void Reset(void)=0;

};

}

