#include <string>
#include <fstream>
#include <iostream>

#include "SimulatorClass.h"
#include "TrafficModelObject.h"
#include "VehicleClass.h"
#include "PhaseClass.h"
#include "TrafficNodeClass.h"
#include "VehicleQueueClass.h"
#include "DestinationClass.h"
#include "IntersectionClass.h"

#include "RoadSegmentClass.h"
#include "ParkingLotClass.h"

#include "TrafficModelClass.h"



namespace TrafficModelObjectsLibrary
{

/// <summary>	Default constructor. </summary>
VehicleClass::VehicleClass(void){}


/// <summary>	VehicleClass constructor with parameters. </summary>
///
/// <param name="TrafficModel">	[in,out] If non-null, pointer to the traffic model. </param>
/// <param name="Destination"> 	Integer ID for the Destination for the vehicle. </param>
/// <param name="IssuedBy">	   	ID/Index of the parking lot that issued the VehicleClass object. </param>
/// <param name="ID">		   	The identifier. </param>
VehicleClass::VehicleClass(TrafficModelObject* TrafficModel, int Destination, int IssuedBy, int ID)
{
	mType = VEHICLE;
	mNext = nullptr;
	mStartTime = 0;
	mTravelTime = 0;
	mTrafficModel = TrafficModel;
	if (Destination < 1 || Destination > ((TrafficModelClass*)mTrafficModel)->DestinationsCount())
	{
		mDestination = 0;
	}
	else
	{
		mDestination = Destination;
	}
	mIssuedBy = IssuedBy;
	mID = ID;
}


/// <summary>	Destructor. </summary>
VehicleClass::~VehicleClass(void)
{
}

void VehicleClass::Release(void)
{
	mNext = nullptr;
	mTrafficModel = nullptr;
}



/// <summary>	Gets the destination. </summary>
///
/// <returns>	The destination. </returns>
int VehicleClass::getDestination(){

 return mDestination;
}

/// <summary>	Sets a next. </summary>
///
/// <param name="Vehicle">	[in,out] If non-null, the vehicle. </param>
void VehicleClass::setNext(VehicleClass * Vehicle)
{
	mNext = Vehicle;
}

/// <summary>	Gets the next VehicleClass object. </summary>
///
/// <returns>	If there is no next VehicleClass object returns null. </returns>
VehicleClass * VehicleClass::Next(void)
{
	return mNext;
}

/// <summary>	Sets a start time. </summary>
///
/// <param name="StartTime">	The start time. </param>
void VehicleClass::setStartTime(double StartTime)
{
	mStartTime = StartTime;
}

/// <summary>	Sets a travel time. </summary>
///
/// <param name="TravelTime">	Time of the travel. </param>
void VehicleClass::setTravelTime(double TravelTime)
{
	mTravelTime = TravelTime;
}

/// <summary>	Gets the travel time. </summary>
///
/// <returns>	The travel time. </returns>
double VehicleClass::getTravelTime(void)
{
	return mTravelTime;
}

/// <summary>	Convert this object into a string representation. </summary>
///
/// <returns>	This object as a char*. </returns>
char* VehicleClass::ToString(void)
{
	char* str;
	str = (char*) malloc (16*sizeof(char));
	sprintf(str,"%d_%d_%d\0",mIssuedBy,mID,mDestination);
	return str;
}

}
