#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"

namespace TrafficModelObjectsLibrary
{



	/// <summary>	Initializes a new instance of the PhaseClass class. </summary>
	///
	/// <param name="Index">		 	Index of the pointer to this Phase in the pointers to phases
	/// 								list in the intersection . </param>
	/// <param name="QueuesIn">		 	The number of vehicle queues that are being served by the
	/// 								phase. </param>
	/// <param name="AvgServiceTime">	The interval of time at which the phase is going to run. </param>
    PhaseClass::PhaseClass(int Index, int QueuesIn, double AvgServiceTime)
    {
        // QueuesIn - number of RoadSegments or ParkingLots providing vehicles to intersection during
        //            this Phase
		mType = PHASE;
        mVehicleQueuesIn = QueuesIn;
		mVehicleQueuesInCount = 0;
		mAverageServiceTime = AvgServiceTime;
		mIndexInNode = Index;
        mVehicleQueuesInList = (TrafficModelObject **) malloc (QueuesIn * sizeof(VehicleQueueClass *));
      
    }


    
    /// <summary>	Constructor. </summary>
    PhaseClass::PhaseClass(){}
    
    /// <summary>	Destructor. </summary>
    PhaseClass::~PhaseClass(){}
    
    /// <summary>	Gets the average service time. </summary>
    ///
    /// <returns>	The average service time. </returns>
    double PhaseClass::GetAverageServiceTime(void)
    {
         return mAverageServiceTime;
    }



     
/// <summary>	Gets a vehicle queue in. </summary>
///
/// <param name="Index">	Zero-based index of the. </param>
///
/// <returns>	null if it fails, else the vehicle queue in. </returns>
TrafficModelObject * PhaseClass::GetVehicleQueueIn(int Index)
{
    if (Index < mVehicleQueuesInCount)
    {
        return mVehicleQueuesInList[Index];
    }
    else
    {
        return NULL;
    }
    
}

/// <summary>	Adds a vehicle queue in. </summary>
///
/// <param name="QueueIn">	[in,out] If non-null, the queue in. </param>
void PhaseClass::AddVehicleQueueIn(TrafficModelObject* QueueIn)
{
    if (mVehicleQueuesInCount < mVehicleQueuesIn)
    {
        mVehicleQueuesInList[mVehicleQueuesInCount] = QueueIn;
        mVehicleQueuesInCount++;
    }   
}


/// <summary>	Gets the index in node. </summary>
///
/// <returns>	The index in node. </returns>
int PhaseClass::GetIndexInNode(void)
{
    return mIndexInNode;
}

/// <summary>	Gets the vehicle queues in. </summary>
///
/// <returns>	The vehicle queues in. </returns>
int PhaseClass::GetVehicleQueuesIn(void)
{
    return mVehicleQueuesIn;
}

/// <summary>	Gets the vehicle queues in count. </summary>
///
/// <returns>	The vehicle queues in count. </returns>
int PhaseClass::GetVehicleQueuesInCount(void)
{
    return mVehicleQueuesInCount;
}

bool PhaseClass::HasVehiclesReady(void)
{
	for(int i = 0;i < mVehicleQueuesInCount; i++)
	{
		if (((VehicleQueueClass*)mVehicleQueuesInList[i])->HasVehiclesReady())
			return true;
	}
	return false;
}

}
