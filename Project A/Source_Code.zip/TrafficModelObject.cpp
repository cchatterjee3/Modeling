
#include "TrafficModelObject.h"

namespace TrafficModelObjectsLibrary
{

/// <summary>	Default constructor. </summary>
TrafficModelObject::TrafficModelObject(void)
{
}


/// <summary>	Destructor. </summary>
TrafficModelObject::~TrafficModelObject(void)
{
}

/// <summary>	Gets the type. </summary>
///
/// <returns>	. </returns>
ObjectType TrafficModelObject::Type()
{
	return mType;
}
}
