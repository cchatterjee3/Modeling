
#include "Event.h"
#include "TrafficModelEvent.h"

namespace TrafficModelEventLibrary
{

/// <summary> Initializes a new instance of the TrafficModelEvent class </summary>
TrafficModelEvent::TrafficModelEvent(void)
{
}


/// <summary> Finalizes an instance of the TrafficModelEvent class </summary>
TrafficModelEvent::~TrafficModelEvent(void)
{
}

/// <summary>	Sets the time of event. </summary>
///
/// <param name="EventTime">	Time of the event. </param>
void TrafficModelEvent::SetEventTime(double EventTime)
{
    mEventTime = EventTime;
}

/// <summary>	Gets the type. </summary>
///
/// <returns>	. </returns>
EventType TrafficModelEvent::Type(void)
{
	return mType;
}

}
