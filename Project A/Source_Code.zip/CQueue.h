#pragma once

namespace SimulatorObjectsLibrary
{

/// <summary>Calendar Queue class </summary>
class CQueue:
	public SimulatorClass
{
protected:
	/// <summary> The head pointer to the array of buckets </summary>
	Event** bucket;
	/// <summary> The number of events currently stored in the queue </summary>
	int qsize;
	/// <summary> The number of buckets currently in the queue </summary>
	int nbucket;
	/// <summary> The width of each bucket ie. the range of timestamps in bucket </summary>
	double width;
	/// <summary> The maximum number of events that can be stored before resizing </summary>
	int max;
	/// <summary> The mimimum number of events that can be stored before resizing </summary>
	int min;
	/// <summary> The current bucket to start searching for the next event </summary>
	int curBucket;
	/// <summary> The latest time stamp possible to be stored in the current bucket for the current cycle </summary>
	double curBucketLatest;
	/// <summary> The time stamp of the latest dequeued event </summary>
	double prevTime;
	/// <summary> Switch that determines if resize is done if max or min is reached </summary>
	bool resizeEnabled;

private:
	/// <summary> Insert a new event at bucket[i] </summary>
	///
	/// <param name="i"> The bucket number to insert event to </param>
	/// <param name="nEvent"> The pointer to the new event node </param>
	void Insert(int i,Event* nEvent);

	/// <summary>Return the head Event node at bucket[i].</summary>
	///
	/// <param name="i">	The bucket number to remove event from.</param>
	///
	/// <returns>null if it fails, else.</returns>
	Event* Remove(int i);
	
	/// <summary> Initializes a new array of buckets based on given parameters </summary>
	///
	/// <param name="num"> The number of buckets to initialize </param>
	/// <param name="wid"> The width of the buckets </param>
	/// <param name="earliest"> The earliest event in the new list </param>
	void init(int num,double wid,double earliest);
	
	/// <summary> Calculates a new suggested width for the resized bucket based on a sample of latest events in the current queue </summary>
	///
	/// <returns> The new width calculated </returns>
	double newwidth(void);
	
	/// <summary> Resizes the calendar to the given number of bickets </summary>
	///
	/// <param name="newSize"> The new number of buckets needed </param>
	void resize(int newSize);

public:

	/// <summary> Initializes a new instance of the CQueue class and internal structure </summary>
	CQueue(void);
	/// <summary> Finalizes the instance of the CQueue class </summary>
	~CQueue(void);

	/// <summary> Adds an event to the Calendar Queue </summary>
	///
	/// <param name="newEvent"> Pointer to the new event to enqueue </param>
	///
	/// <returns> True </returns>
	virtual bool AddEvent(Event *newEvent);

	/// <summary>Removes a particular event from the queue.</summary>
	///
	/// <param name="ptrEvent">	[in,out] If non-null, the pointer event.</param>
	///
	/// <returns>Pointer to the event removed from the queue.</returns>
	virtual Event* PopEvent(Event *ptrEvent);
	
	/// <summary> Removes the earliest event from the Calendar Queue </summary>
	///
	/// <returns> Pointer to the earliest event in the calendar queue </returns>
	virtual Event* PopNext(void);

	/// <summary>Checks if the queue is empty.</summary>
	///
	/// <returns>true is qsize=0, false otherwise.</returns>
	virtual bool IsEmpty(void);
	
	/// <summary> Prints out the current internal structure of the queue </summary>	
	void print(void);

	virtual void Reset(void);
};

}
