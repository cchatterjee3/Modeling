
#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"
#include "TrafficModelEvent.h"
#include "VehicleExitsIntersectionEvent.h"
#include "VehicleAtFrontEvent.h"
#include "PhaseChangeEvent.h"

namespace TrafficModelEventLibrary
{


VehicleAtFrontEvent::VehicleAtFrontEvent(void)
{
}

/// <summary>	Initializes a new instance of the VehicleAtFrontEvent class. </summary>
///
/// <param name="VehicleQueue">	[in,out] If non-null, queue of vehicles. </param>
/// <param name="Vehicle">	   	[in,out] If non-null, the vehicle. </param>
/// <param name="EventTime">   	Time of the event. </param>
VehicleAtFrontEvent::VehicleAtFrontEvent(VehicleQueueClass* VehicleQueue, VehicleClass* Vehicle, double EventTime)
{
	mType = VEHICLE_AT_FRONT;
	mNext = nullptr;
	mEventTime = EventTime;
	mVehicleQueue = VehicleQueue;
	mVehicle = Vehicle;
	
}

/// <summary>	Destructor. </summary>
VehicleAtFrontEvent::~VehicleAtFrontEvent(void)
{
}

void VehicleAtFrontEvent::Release(void)
{
	mVehicle = nullptr;
	mVehicleQueue = nullptr;
	mVehicle = nullptr;
	mNext = nullptr;
}

/// <summary>	Runs this Event. </summary>
void VehicleAtFrontEvent::Run(void)
{
	if (mVehicleQueue->FrontRowClear())
	{
		// 1. check active phase
		//   if active phase != queue phase
		//   Check intersection status
		TrafficNodeClass * Intersection = mVehicleQueue->EndTrafficNode();
		if (Intersection->IsIdle())
		{
			PhaseClass * Phase = mVehicleQueue->Phase();
			int Destination = mVehicle->getDestination();
			if (!Intersection->VehicleQueueOutIsFull(Destination))
			{
				double PhaseTime = Intersection->SetActivePhase(Phase->GetIndexInNode());
				SimulatorClass * Simulator = ((TrafficModelClass*)Intersection->TrafficModel())->Simulator();
			    clsRandomGenerator * RandomGenerator =  ((TrafficModelClass*)Intersection->TrafficModel())->RandomGenerator();
	            TrafficModelEvent* NextPhaseChangeEvent = (TrafficModelEvent*)Intersection->NextPhaseChangeScheduledEvent();
			    if (NextPhaseChangeEvent)
			    {
				    Simulator->PopEvent(NextPhaseChangeEvent);
				}
				
				PhaseTime = RandomGenerator->UniformDist(TIME_ERROR_LB * PhaseTime, TIME_ERROR_UB * PhaseTime);
				NextPhaseChangeEvent = new PhaseChangeEvent((IntersectionClass*)Intersection, mEventTime + PhaseTime);
				Simulator->AddEvent(NextPhaseChangeEvent);
				
				
				double tempTime = mVehicleQueue->GetIntersectionCrossingTime(Destination);
				tempTime = RandomGenerator->UniformDist(TIME_ERROR_LB * tempTime, TIME_ERROR_LB * tempTime);
				mVehicle->setTravelTime(mEventTime + tempTime);
				Intersection->VehicleIn(mVehicle);
				return;
		     }
		}

	}

	mVehicleQueue->AddVehicleReady(mVehicle);
	
}

}
