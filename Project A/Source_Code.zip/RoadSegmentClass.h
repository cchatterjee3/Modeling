#pragma once

namespace TrafficModelObjectsLibrary
{

/// <summary>Road segment class.</summary>
class RoadSegmentClass :
	public VehicleQueueClass
{
protected:

	/// <summary>The index of the node at which the road segment starts.</summary>
	int mStartTrafficNodeIndex;
	/// <summary>The pointer to the node that starts the road segment. </summary>
	TrafficNodeClass* ptrStartTrafficNode;

public:

	/// <summary>Initializes a new instance of the RoadSegmentClass class.</summary>
	RoadSegmentClass(void);

	/// <summary>Initializes a new instance of the RoadSegmentClass class.</summary>
	///
	/// <param name="Index">                Index of the pointer to the Road Segment into the Vehicle Queue list of the Model.</param>
	/// <param name="TrafficModel">         Pointer to the model.</param>
	/// <param name="Capacity">		The capacity of the road segment.</param>
	/// <param name="AverageTravelTime">	The average time is takes a vehicle to cross the road segment freely.</param>
	/// <param name="Lanes">		The number of lanes for the road segment.</param>
	/// <param name="StartTrafficNode"> 	The node at which the road segment starts.</param>
	/// <param name="EndTrafficNode">   	The node at which the road segment ends.</param>
	/// <param name="Phase">		The phase at which the vehicle queue in is going to be served at the intersection ahead.</param>
	/// <param name="DestinationsCount">	The number of destinations the road segment serves.</param>
		RoadSegmentClass(int Index, TrafficModelObject* TrafficModel, int Capacity,  double AverageTravelTime, int Lanes, int StartTrafficNode, int EndTrafficNode, int Phase, int DestinationsCount);
	
	/// <summary>Finalizes an instance of the RoadSegmentClass class.</summary>
	~RoadSegmentClass(void);

	/// <summary> Gets the vehicle out of the road segment and passes it to the intersection .</summary>
	///
	/// <param name="Time">	The time that the vehicle will take to cross the intersection ahead .</param>
	///
	/// <returns>null if it fails, returns a pointer to the vehicle issued by the road segment.</returns>
	virtual VehicleClass *VehicleOut(double Time);

	virtual void SetToStart(void);
};

}
