
#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"
#include "TrafficModelEvent.h"
#include "VehicleAtFrontEvent.h"
#include "SeekVehicleEvent.h"
#include "VehicleExitsIntersectionEvent.h"

namespace TrafficModelEventLibrary
{

/// <summary>	Constructor for a new instance of the VehicleExitsIntersectionEvent class. </summary>
VehicleExitsIntersectionEvent::VehicleExitsIntersectionEvent(void){}

/// <summary>	Initializes a new instance of the VehicleExitsIntersectionEvent class. </summary>
///
/// <param name="Vehicle">		  	[in,out] Pointer to the vehicle. </param>
/// <param name="Intersection">   	[in,out] Pointer to the intersection. </param>
/// <param name="VehicleQueueOut">	[in,out] Pointer to the outgoing vehicle queue. </param>
/// <param name="EventTime">	  	Time of the event. </param>
VehicleExitsIntersectionEvent::VehicleExitsIntersectionEvent(VehicleClass* Vehicle, TrafficNodeClass *Intersection, VehicleQueueClass* VehicleQueueOut, double EventTime)
{
	mType = VEHICLE_EXITS_INTERSECTION;
	mNext = nullptr;
    mEventTime = EventTime;
	mVehicle=Vehicle;
    mIntersection=Intersection;
    mVehicleQueueOut = VehicleQueueOut;
    
}

/// <summary>	Destructor. </summary>
VehicleExitsIntersectionEvent::~VehicleExitsIntersectionEvent(void)
{
}

void VehicleExitsIntersectionEvent::Release(void)
{
	mNext = nullptr;
	mVehicle=nullptr;
    mIntersection=nullptr;
    mVehicleQueueOut = nullptr;
}

/// <summary>	Runs this Event. </summary>
void VehicleExitsIntersectionEvent::Run(void)
{
    SimulatorClass * Simulator = ((TrafficModelClass*)mIntersection->TrafficModel())->Simulator();
	double RoadSegmentTravelTime = mVehicleQueueOut->GetAverageTravelTime();
	mIntersection->VehicleOut();
	Simulator->AddEvent(new VehicleAtFrontEvent(mVehicleQueueOut, mVehicle, mEventTime + RoadSegmentTravelTime));
	
	if (((TrafficModelClass*)mIntersection->TrafficModel())->Trace()) 
	{
		ostream * outStr = ((TrafficModelClass*)mIntersection->TrafficModel())->getOutputStream();
		*outStr  << "V In RS " << mVehicleQueueOut->IndexInList() << ":\t" << mVehicle->ToString() << '\t' << mEventTime << '\n';
		*outStr  << "V Rdy RS " << mVehicleQueueOut->IndexInList() << ":\t" << mVehicle->ToString() << '\t' << mEventTime + RoadSegmentTravelTime << '\n';
	}

	if(mIntersection->IsEmpty())
	{
	   PhaseClass* currentPhase = mIntersection->ActivePhase();
	   int numQueuesIn = currentPhase->GetVehicleQueuesInCount();
	   int numLanes;

	   for(int i=0; i < numQueuesIn; i++)
	   {
	    	numLanes = ((VehicleQueueClass*)currentPhase->GetVehicleQueueIn(i))->Exits();
			double TakeOffTime;
	    	clsRandomGenerator * RandomGenerator =  ((TrafficModelClass*)mIntersection->TrafficModel())->RandomGenerator();
	        for (int j=0; j < numLanes; j++)
	    	{
				TakeOffTime = RandomGenerator->UniformDist(TAKEOFF_TIME_LB, TAKEOFF_TIME_UB);
				Simulator->AddEvent(new SeekVehicleEvent((IntersectionClass*)mIntersection, (VehicleQueueClass*)currentPhase->GetVehicleQueueIn(i), mEventTime + TakeOffTime)); 
			}
	   }
	}
}

}
