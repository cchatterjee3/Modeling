#include<iostream>
#include<cstdlib>
#include "SimulatorClass.h"
#include "CQueue.h"

using namespace std;

namespace SimulatorObjectsLibrary
{


/// <summary>	Default constructor. </summary>
CQueue::CQueue(void)
{
	init(2,1.0,0.0);
	resizeEnabled = true;
}

/// <summary>	Destructor. </summary>
CQueue::~CQueue(void)
{
    int i;
	Event* temp;

	for(i=nbucket-1;i>=0;i--)
	{
		while(bucket[i]!=NULL)
		{
			temp = bucket[i]->Next();
			free(bucket[i]);
			bucket[i] = temp;
		}
	}

	free(bucket);
}

/// <summary>	Initializes a new array of buckets based on given parameters. </summary>
///
/// <param name="num">	   	The number of buckets to initialize. </param>
/// <param name="wid">	   	The width of the buckets. </param>
/// <param name="earliest">	The earliest event in the new list. </param>
void CQueue::init(int num,double wid,double earliest)//no. of buckets,bucket width, earliest event in bucket
{
	int i,t;

	bucket = (Event**)malloc(num*sizeof(Event*));       //allocate num buckets
	nbucket = num;
	width = wid;
	qsize = 0;
	for(i=0;i<nbucket;i++)
		bucket[i] = NULL;
	prevTime = earliest;
	t = (int)(earliest/width);
	curBucket = t % nbucket;                        //point to the bucket to start dequeueing from
	curBucketLatest = (t+1.5)*width;
	min = nbucket/2-2;
	max = 2*nbucket;

	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds an event to the Calendar Queue. </summary>
///
/// <param name="newEvent">	[in,out] Pointer to the new event to enqueue. </param>
///
/// <returns>	True. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

bool CQueue::AddEvent(Event* newEvent)
{
	int i;

	i = (int)(newEvent->EventTime()/width);				//point to the bucket to enqueue current event
	i = i%nbucket;

	Insert(i,newEvent);							//insert at the given bucket

	qsize++;

	if(qsize>max && resizeEnabled)
		resize(2*nbucket);

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Insert a new event at bucket[i]. </summary>
///
/// <param name="i">	 	The bucket number to insert event to. </param>
/// <param name="nEvent">	[in,out] The pointer to the new event node. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CQueue::Insert(int i,Event* nEvent)
{
	Event *cur,*prev;

	cur = bucket[i];
	prev = NULL;

	while(cur && cur->EventTime() < nEvent->EventTime())
	{							//Traverse through linked list at bucket
		prev = cur;
		cur = cur->Next();
	}

	if(prev == NULL)
	{
		bucket[i] = nEvent;
		nEvent->SetNext(cur);
	}
	else
	{
		prev->SetNext(nEvent);
		nEvent->SetNext(cur);
	}

	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Removes a particular event from the queue. </summary>
///
/// <param name="ptrEvent">	[in,out] If non-null, the pointer event. </param>
///
/// <returns>	Pointer to the event removed from the queue. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

Event* CQueue::PopEvent(Event* ptrEvent)
{
	int i;
	Event* cur,*prev;

	i = (int)(ptrEvent->EventTime()/width);		//point to the bucket which contains the event
	i = i%nbucket;

	cur = bucket[i];
	prev = NULL;

	while(cur && cur != ptrEvent)
	{							//Traverse through linked list at bucket
		prev = cur;
		cur = cur->Next();
	}

	if (cur == ptrEvent)
	{
		if(prev == NULL)
		{
			bucket[i] = cur->Next();
		}
		else
		{
			prev->SetNext(cur->Next());
	    }

		qsize--;

		return cur;  //return the given pointer
	}
	else
	{
		return nullptr; // Event not in Queue
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Query if this object is empty. </summary>
///
/// <returns>	true if empty, false if not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

bool CQueue::IsEmpty(void)
{
	return qsize==0?true:false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Pops the next. </summary>
///
/// <returns>	null if it fails, else. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

Event* CQueue::PopNext(void)
{
	int i=curBucket;
	Event* first;

	first = NULL;

	if(qsize==0)
		return first;			//return null if queue is empty

	do
	{
		if(bucket[i]!=NULL && bucket[i]->EventTime()<curBucketLatest) //current buckets' events are in the current cycle
		{
			first = Remove(i);
			curBucket = i;
			prevTime = first->EventTime();
			qsize--;
		}
		else					//increment to next bucket if event not found
		{
			i++;
			if(i==nbucket)
				i=0;
			curBucketLatest += width;
		}
	}while(first==NULL);

	if(qsize<min && resizeEnabled)
		resize(nbucket/2);

	return first;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Return the head Event node at bucket[i]. </summary>
///
/// <param name="i">	The bucket number to remove event from. </param>
///
/// <returns>	null if it fails, else. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

Event* CQueue::Remove(int i)
{
	Event* cur;

	cur = bucket[i];

	bucket[i] = cur->Next();

	return cur;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Resizes the calendar to the given number of bickets. </summary>
///
/// <param name="newSize">	The new number of buckets needed. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CQueue::resize(int newSize)
{
	double bwidth;
	int i,oldSize;
	Event** oldbucket;
	Event* temp;

	bwidth = newwidth();

	oldbucket = bucket;
	oldSize = nbucket;

	init(newSize,bwidth,prevTime);
	for(i=oldSize-1;i>=0;i--)
	{
		while(oldbucket[i]!=NULL)
		{
			temp = oldbucket[i]->Next();
			AddEvent(oldbucket[i]);
			oldbucket[i] = temp;
		}
	}

	free(oldbucket);

	return;
}

/// <summary>
/// Calculates a new suggested width for the resized bucket based on a sample of latest events in
/// the current queue.
/// </summary>
///
/// <returns>	The new width calculated. </returns>
double CQueue::newwidth(void)
{
	int i,t;
	int nsamples;
	int tcurBucket;
	double tcurBucketLatest,tprevTime;
	Event** sample;
	double* separation;
	double average,total=0;

	if(qsize<2)
		return 1.0;
	if(qsize <= 5)
		nsamples = qsize;
	else
		nsamples = 5 + qsize/10;
	if(nsamples > 25)
		nsamples = 25;

	//back-up old parameters
	tcurBucket = curBucket;
	tcurBucketLatest = curBucketLatest;
	tprevTime = prevTime;

	sample = (Event**)malloc(nsamples*sizeof(Event*));
	separation = (double*)malloc((nsamples-1)*sizeof(double));
	resizeEnabled = false;

	sample[0] = PopNext();

	//Dequeue samples to check and store separation
	for(i=1;i<nsamples;i++)
	{
		sample[i] = PopNext();
		separation[i-1] = (sample[i]->EventTime() - sample[i-1]->EventTime());
		total += separation[i-1];
	}

	//Restore back to original state
	for(i=0;i<nsamples;i++)
	{
		AddEvent(sample[i]);
	}
	curBucket = tcurBucket;
	curBucketLatest = tcurBucketLatest;
	prevTime = tprevTime;
	resizeEnabled = true;

	//calculate average separation
	average = total/(nsamples-1);
	total = 0;
	t = 0;

	for(i=0;i<nsamples-1;i++)
	{
		if(separation[i]<=2*average)
		{
			total += separation[i];
			t++;
		}
	}
	
	if(t==0) t=1;

	average = total/t;

	if(average <= 0.0) return width/2.0;

	return 3.0*average;
}

/// <summary>	Prints this object. </summary>
void CQueue::print(void)
{
	int i;
	Event* cur;

	cout << "Width = " << width << endl;
	cout << "qsize = " << qsize << endl;
	cout << curBucket << " " << curBucketLatest << " " << prevTime << endl;
	for(i=0;i<nbucket;i++)
	{
		cout << "Bucket " << i << "-->";
		cur = bucket[i];
		while(cur != NULL)
		{
			cout << cur->EventTime() << "-->";
			cur = cur->Next();
		}
		cout << endl;
	}
	cout << "min " << min << " max " << max << endl;

	return;
}

void CQueue::Reset(void)
{
	 init(2,1.0,0.0);
}
}
