// Modeler.cpp : Defines the entry point for the console application.
//
#include <string>
#include <fstream>
#include <iostream>
#include <time.h>
#include "SimulatorClass.h"
#include "CQueue.h"
#include "LinkedListPQClass.h"
#include "TrafficModelObjectsLibrary.h"
#include "TrafficModelEventsLibrary.h"


using namespace TrafficModelEventLibrary;
using namespace std;
//namespace Modeler
//{
bool CheckModelConsistency(TrafficModelClass *TrafficModel);

int main(int argc, char* argv[])
{
	// 1. Code to read the open and start reading the file
	ifstream inputfile, inputfile1;
	ofstream outputfile;
	string line;
	char c;

        inputfile1.open("input.txt", ios::in);
	if(!inputfile1.is_open())
        {
            cout << "Error opening input.txt file!\n";
            return 1;
	}

	//Make it machine readable

        outputfile.open("MRinput.txt", ios::out);
	if(!outputfile.is_open())
        {
            cout << "Error opening MRinput.txt file for output!\n";
            return 2;
        }

	while( inputfile1.eof() != true ){
		getline( inputfile1, line );
		if (line.length() > 0)
		{
		if( line.at(0) != '#' ){
			outputfile <<  line << endl;
		}
		}
	}

	outputfile.close();
	inputfile1.close();

        inputfile.open("MRinput.txt", ios::in);
	if(!inputfile.is_open()){
		cout << "Error opening MRinput File for input!\n";
                return 3;
	}

	//Traffic Model Variables
	int numDestinations = 0, numIntersections = 0, numParkingLots = 0, numRoadSegments = 0;

	//Destination Variables
	double avgCrossingTime = 0.0;

	//Intersection Variables
	int numPhases = 0, numQueuesIn = 0, numQueuesOut = 0, QueueID = 0;
	double serveTime = 0.0;

	//ParkingLot Variables
	int parkingCapacity = 0, numExits = 0, endTrafficNode = 0, phase=0, destinationCount = 0, destinationID = 0;
		
	//RoadSegment Variables
	int RSCapacity = 0, RSLanes = 0, StartTrafficNode = 0, EndTrafficNode = 0, RSPhase = 0;
	int DestCount = 0, DestID = 0;
	double RSAverageCrossTime = 0.0, CrossingTimeAtIntersection = 0.0;


	inputfile >> numDestinations >> numIntersections >> numParkingLots >> numRoadSegments; 
       
 

	// 2. Read model info and create an instace of a TrafficModelClass  (assuming you call it theModel)
	TrafficModelClass *TrafficModel = new TrafficModelClass( numDestinations, numIntersections, numParkingLots, numRoadSegments);

	
	// 2.1 Model Options
	int bScreen = 0, bTrace = 0, bCheck = 0, intNumberOfRuns = 0;

	inputfile >> bTrace >> bScreen >> bCheck >> intNumberOfRuns;
	if (bTrace)
	{
		TrafficModel->setTrace(true);
		intNumberOfRuns = 1;
	}

	if (bCheck)
	{
		TrafficModel->setCheck(true);
		intNumberOfRuns = 1;
	}

	// 3. Read each Destination Info and add it to the theModel via theModel->AddDestination(....)
	
	//    at each destination, use the Destination object returned by theModel->AddDestination, to set
	//    the information to the Destination.
	//    i.e. (assuming you use this statement to add the Destination:  
	//                    CurrentDestination = theModel->AddDestination(....);)
	//         add each phase using :     CurrentPhase = CurrentDestination->AddPhase(...)
	//         then you can use CurrentPhase to add the queues in and queues out ...
	//               CurrentPhase->AddVehicleQueueIn(....)
	//               CurrentPhase->AddVehicleQueueOut(....)
	//    
	//    this approach can be used for 4., 5., and 6.


    DestinationClass* currentDestination;
	for( int i=0; i<numDestinations; i++)
        {
		inputfile >> avgCrossingTime;
		currentDestination = TrafficModel->AddDestination(avgCrossingTime); 
	}

       
	// 4. Read each Intersection info and add it to theModel via theModel->AddIntersection(....)
    IntersectionClass* currentIntersection;
    PhaseClass* currentPhase;
	for( int i=0; i<numIntersections; i++)
    {
		inputfile >> numPhases >> numQueuesOut ;
		currentIntersection = TrafficModel->AddIntersection(numPhases, numQueuesOut);

		for(int j=0; j<numPhases; j++)
		{
			inputfile >> serveTime >> numQueuesIn;
		    // The time the phase is going to last
			currentPhase = currentIntersection->AddPhase(numQueuesIn, serveTime);
		}
	}


	// 5. Read each ParkingLot info and add it to theModel via theModel->AddParkingLot(....)
    ParkingLotClass* currentParkingLot;
	for(int i=0; i<numParkingLots; i++)
	{
		inputfile >> parkingCapacity >> numExits >> endTrafficNode >> phase >> destinationCount; 
		currentParkingLot = TrafficModel->AddParkingLot( parkingCapacity, numExits, endTrafficNode, phase, destinationCount);
		for( int h=0; h<destinationCount; h++)
        {
			inputfile >> destinationID >> avgCrossingTime;
			currentParkingLot->SetDestination(h, destinationID, avgCrossingTime);
		}
	}

	// 6. Read each RoadSegment info and add it to theModel via theModel->AddRoadSegment(...)
	RoadSegmentClass* currentRoadSegment;
	for( int j=0; j<numRoadSegments; j++)
	{
		inputfile >> RSCapacity >> RSAverageCrossTime >> RSLanes >> StartTrafficNode >> EndTrafficNode >> RSPhase >> DestCount;
		currentRoadSegment = TrafficModel->AddRoadSegment(RSCapacity, RSAverageCrossTime, RSLanes, StartTrafficNode, EndTrafficNode, RSPhase, DestCount);
		
		for(int i=0; i<DestCount; i++)
		{
			inputfile >> DestID >> CrossingTimeAtIntersection;
	
			// add the destination ID to the current RoadSegmentClass
			currentRoadSegment->SetDestination(i,DestID, CrossingTimeAtIntersection);
		}
	}			
		

	inputfile.close();
				
	if (!bScreen)
	{
            outputfile.open("Output.txt", ios::out);
            if(!outputfile.is_open())
            {
                cout << "Error opening Output.txt File! \n";
                return 4;
            }
            
            TrafficModel->setOutputStream(&outputfile);
	}

	CheckModelConsistency(TrafficModel);		



	// Need to set the simulator.
	TrafficModel->setRandomGenerator(new clsRandomGenerator(1548253522));
	//TrafficModel->setSimulator(new LinkedListPQClass());
	TrafficModel->setSimulator(new CQueue());
	
	TrafficModelEvent* currentEvent;
	SimulatorClass* ptrSimulator = TrafficModel->Simulator();
	ostream* outStr = TrafficModel->getOutputStream();
	DestinationClass* fDestination;

	double startTime = 0.0;
	int intPhaseIndex;
	numParkingLots = TrafficModel->ParkingLotsCount();

	time_t mTimer = time(NULL);

	// Add Headers for Output
	*outStr << "\n\n  \t";
	for( int k=0; k<numDestinations; k++)
	{
			*outStr << "Destination\t" << k << "\t";
	}
	*outStr << "\tTotals \n Run No\t";
	for( int k=0; k<numDestinations; k++)
	{
		    *outStr << "Vehicles Served \tAverage Time \t";
	}
	*outStr << "Vehicles Served \tCummulative Time \tAverage Time";

	// Start the loop of Simulation runs
	for (int j = 0; j < intNumberOfRuns; j++)
	{
		// Set Model to initial conditions
		TrafficModel->SetToStart();
		//TrafficModel->setSimulator(new CQueue());
		ptrSimulator = TrafficModel->Simulator();


	    // 7. Set a Phase Change Event for each Intersection outside a Parking Lot
		for( int i=0; i<numParkingLots; i++)
		{
			currentParkingLot = (ParkingLotClass*)TrafficModel->GetVehicleQueue(i);
		    currentIntersection = (IntersectionClass*)currentParkingLot->EndTrafficNode();
			
			// Set the active phase of the Intersection to the last phase, so that in the next phase change the first phase is going to be active.
			intPhaseIndex = currentParkingLot->Phase()->GetIndexInNode() - 1;
			if (intPhaseIndex > 0) intPhaseIndex += currentIntersection->PhasesCount(); 
			currentIntersection->SetActivePhase(currentPhase->GetIndexInNode());
		
			//Schedule PhaseChangeEvent
			TrafficModel->Simulator()->AddEvent(new PhaseChangeEvent(currentIntersection, startTime));
     	}


		// 8. A while loop until CurrentEvent == null 
		while( !ptrSimulator->IsEmpty())
		{
			currentEvent = (TrafficModelEvent*)ptrSimulator->PopNext();
			currentEvent->SetNext(0);
		    currentEvent->Run();
   			currentEvent->Release();
			delete currentEvent;
		    //*outStr << currentEvent->Type() << '\t' << currentEvent->EventTime() << '\n';
	    }

		// 9. Code to compute and output results
	    //    The info needed should be in the Destination objects of theModel
	    *outStr << "\n" << j << "\t";
	    for( int k=0; k<numDestinations; k++)
	    {
			fDestination = (DestinationClass*)TrafficModel->GetTrafficNode(k);		//Need ptr to all the DestinationNodes
			fDestination->GetVehiclesServed();
		    fDestination->GetAverageTime();

			*outStr << fDestination->GetVehiclesServed() << "\t";
		    *outStr << fDestination->GetAverageTime() << "\t";
		    // Write statistics to a file
		}

		*outStr << TrafficModel->TotalVehiclesServed() << "\t";
		*outStr << TrafficModel->TotalCummulativeTime() << "\t";
		*outStr << TrafficModel->AverageDelayTime() ;
	}
	*outStr << "\n\n Total time : " << time(NULL) - mTimer << " Seconds\n";
	outputfile.close();	


	return 0;
}


bool CheckModelConsistency(TrafficModelClass *TrafficModel ) // If outputfile is null write to output window 
{
	ostream* outStr = TrafficModel->getOutputStream();
   *outStr << "Consistency Check Results\n";
   // 1. Get model info
   // DestinationsCount, IntersectionsCount, ParkingLotsCount, RoadSegmentsCount, NodesCount, VehicleQueuesCount
   // VehicleQueuesCount should be equal to ParkingLotsCount + RoadSegmentsCount
   // likewise NodesCount = DestinationsCount + IntersectionsCount
   int numDestinations = TrafficModel->DestinationsCount();

   //2. Check Consistency of the mNodesList, and mVehicleQueuesList
   // use TrafficModel->GetTrafficNode(int Index), and TrafficModel->GetVehicleQueue(int Index)
   // Remember from 0 to numDestinations -1, the object type should be DESTINATION, from numDestinations and above the object type should be INTERSECTION

   //3. Check consistency of each Intersection
   // from numDestinations to NodesCount -1
   // Compare PhasesMax with Phases Count. Those two values should be equal
   // at each Phase, compare VehicleQueuesIn with VehicleQueuesInCount. Those two values should be equal

   // at each phase, get a pointer to each VehicleQueueIn and for each Destination check that there is one and only one QueueOut in the Intersection that is valid for that particular destination


 
return true;
}
//}
