#include <string>
#include <fstream>
#include <iostream>
#include "SimulatorClass.h"
#include "TrafficModelObjectsLibrary.h"

#include "TrafficModelEvent.h"
#include "VehicleExitsIntersectionEvent.h"
#include "SeekVehicleEvent.h"

namespace TrafficModelEventLibrary
{

SeekVehicleEvent::SeekVehicleEvent(void)
{
}


SeekVehicleEvent::~SeekVehicleEvent(void)
{
}

void SeekVehicleEvent::Release(void)
{
	mNext = nullptr;
	mEventTime = nullptr;
	mIntersection = nullptr;
	mVehicleQueueIn = nullptr;
}

/// <summary>	Initializes a new instance of the SeekVehicleEvent class. </summary>
///
/// <param name="Intersection">  	[in,out] If non-null, the intersection. </param>
/// <param name="VehicleQueueIn">	[in,out] If non-null, the vehicle queue in. </param>
/// <param name="EventTime">	 	Time of the event. </param>
SeekVehicleEvent::SeekVehicleEvent(IntersectionClass* Intersection, VehicleQueueClass* VehicleQueueIn, double EventTime)
{
	mType = SEEK_VEHICLE;
	mNext = nullptr;
	mEventTime = EventTime;
	mIntersection = Intersection;
	mVehicleQueueIn = VehicleQueueIn;
	
}

/// <summary>	Runs this Event. </summary>
void SeekVehicleEvent::Run(void)
{
	if (mIntersection->ActivePhaseIndex() == mVehicleQueueIn->Phase()->GetIndexInNode()) 
	{
		SimulatorClass * Simulator = ((TrafficModelClass*)mIntersection->TrafficModel())->Simulator();
		clsRandomGenerator * RandomGenerator =  ((TrafficModelClass*)mIntersection->TrafficModel())->RandomGenerator();

		if (mVehicleQueueIn->HasVehiclesReady())
		{
			int nextDestination = mVehicleQueueIn->GetNextVehicleDestination();
			if (!mIntersection->VehicleQueueOutIsFull(nextDestination))
			{
				VehicleClass* Vehicle = mVehicleQueueIn->VehicleOut(mEventTime);
				double tempTime =  mVehicleQueueIn->GetIntersectionCrossingTime(nextDestination);
				tempTime = RandomGenerator->UniformDist(TIME_ERROR_LB * tempTime, TIME_ERROR_LB * tempTime);
				Vehicle->setTravelTime(mEventTime + tempTime);
				mIntersection->VehicleIn(Vehicle);
	   			tempTime = RandomGenerator->UniformDist(HEADWAY_TIME_LB, HEADWAY_TIME_UB);
				Simulator->AddEvent(new SeekVehicleEvent(mIntersection, mVehicleQueueIn, mEventTime + tempTime));
			}
		}
	}
}

}
